// ============================================================
//  FiveM Live Streamers Panel - Twitch + Kick + TikTok
//  Backend: Node.js 20+ / Express
// ============================================================
require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
app.set('trust proxy', 1); // per Nginx
app.disable('x-powered-by');

// ---------- Header-at e sigurise ----------
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com",
  "img-src 'self' data: https:",
  "connect-src 'self'",
  "frame-src https://player.twitch.tv https://player.kick.com https://www.youtube.com https://www.youtube-nocookie.com",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');
app.use((req, res, next) => {
  res.set({
    'Content-Security-Policy': CSP,
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
  });
  if (req.secure) res.set('Strict-Transport-Security', 'max-age=15552000');
  if (req.path.startsWith('/api/')) res.set('Cache-Control', 'no-store');
  next();
});

// ---------- Limit i pergjithshem: max 300 kerkesa API ne minute per IP (shume lojtare mund te ndajne te njejten IP nga operatori celular) ----------
const apiHits = new Map(); // ip -> { n, reset }
app.use((req, res, next) => {
  if (!req.path.startsWith('/api/')) return next();
  const now = Date.now(), ip = req.ip || '-';
  let h = apiHits.get(ip);
  if (!h || h.reset < now) { h = { n: 0, reset: now + 60 * 1000 }; apiHits.set(ip, h); }
  if (++h.n > 300) {
    res.set('Retry-After', String(Math.ceil((h.reset - now) / 1000)));
    return res.status(429).json({ error: 'Shumë kërkesa. Provo përsëri pas pak.' });
  }
  next();
});

const jsonSmall = express.json({ limit: '200kb' });
const jsonUpload = express.json({ limit: '6mb' }); // vetem per ngarkimin e fotove nga admini
// Ngarkimi i madh lexohet vetem pasi kontrollohet qe eshte admini
app.use((req, res, next) => {
  // Tebex: duhet trupi origjinal (raw) per te verifikuar nenshkrimin
  if (req.path === '/api/tebex/webhook' && req.method === 'POST') {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > 200 * 1024) req.destroy(); else chunks.push(c); });
    req.on('end', () => { req.rawBody = Buffer.concat(chunks).toString('utf8'); next(); });
    req.on('error', () => res.status(400).end());
    return;
  }
  return req.path === '/api/admin/upload'
    ? requireAdmin(req, res, () => jsonUpload(req, res, next))
    : jsonSmall(req, res, next);
});

const list = v => (v || '').split(',').map(s => s.trim().toLowerCase().replace(/^@/, '')).filter(Boolean);

// ---------------- KONFIGURIMI ----------------
const CONFIG = {
  PORT: process.env.PORT || 3000,
  CACHE_SECONDS: Number(process.env.CACHE_SECONDS || 60),

  // Emri / tag-u i serverit ne titullin e stream-it (p.sh. "emriserverit,#emriserverit")
  // Nese lihet bosh, shfaqen te gjithe streamerat e listes qe jane live (ne GTA V per Twitch/Kick)
  TITLE_KEYWORDS: list(process.env.TITLE_KEYWORDS),

  TWITCH: {
    get CLIENT_ID() { return settings.twitchClientId || process.env.TWITCH_CLIENT_ID; },
    get CLIENT_SECRET() { return settings.twitchClientSecret || process.env.TWITCH_CLIENT_SECRET; },
    STREAMERS: list(process.env.TWITCH_STREAMERS),
    SCAN_ALL_GTA: process.env.TWITCH_SCAN_ALL_GTA === 'true', // gjen edhe streamera jashte listes
  },
  KICK: {
    get CLIENT_ID() { return settings.kickClientId || process.env.KICK_CLIENT_ID; },
    get CLIENT_SECRET() { return settings.kickClientSecret || process.env.KICK_CLIENT_SECRET; },
    STREAMERS: list(process.env.KICK_STREAMERS), // slug-u i kanalit (kick.com/<slug>)
  },
  TIKTOK: {
    STREAMERS: list(process.env.TIKTOK_STREAMERS), // username pa @
    SIGN_API_KEY: process.env.TIKTOK_SIGN_API_KEY || undefined, // opsionale (eulerstream.com)
  },
};

// ============================================================
//  TE DHENAT QE NDRYSHON ADMINI (ruhen ne folderin data/)
// ============================================================
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

function readJSON(name, fallback) {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, name), 'utf8')); }
  catch { return fallback; }
}
function writeJSON(name, obj) {
  const file = path.join(DATA_DIR, name);
  fs.writeFileSync(file + '.tmp', JSON.stringify(obj, null, 2), { mode: 0o600 });
  fs.renameSync(file + '.tmp', file);
}

// ---------- Regjistri i adminit (kush hyri, kur dhe cfare ndryshoi; kurre fjalekalime apo celesa) ----------
const AUDIT_FILE = path.join(DATA_DIR, 'admin.log');
function audit(req, action, detail = '') {
  try {
    const ip = String(req?.ip || '-').replace(/[^\w.:]/g, '').slice(0, 45);
    const line = `${new Date().toISOString()} | ${ip} | ${action}${detail ? ' | ' + String(detail).replace(/[\r\n|]/g, ' ').slice(0, 200) : ''}\n`;
    fs.appendFileSync(AUDIT_FILE, line, { mode: 0o600 });
    // mbaje skedarin te vogel (max ~500 KB)
    if (fs.statSync(AUDIT_FILE).size > 512 * 1024) {
      const lines = fs.readFileSync(AUDIT_FILE, 'utf8').trim().split('\n');
      fs.writeFileSync(AUDIT_FILE, lines.slice(-2000).join('\n') + '\n', { mode: 0o600 });
    }
  } catch { /* disku nuk duhet ta ndaloje faqen */ }
}

const DEFAULT_SETTINGS = {
  discord: process.env.DISCORD_INVITE || '',
  cfxCode: process.env.FIVEM_CODE || '',
  titleKeywords: CONFIG.TITLE_KEYWORDS,
  streamers: { twitch: CONFIG.TWITCH.STREAMERS, kick: CONFIG.KICK.STREAMERS, tiktok: CONFIG.TIKTOK.STREAMERS },
  tebexToken: process.env.TEBEX_TOKEN || '',
  tebexStoreUrl: process.env.TEBEX_STORE_URL || '',
  twitchClientId: '', twitchClientSecret: '', kickClientId: '', kickClientSecret: '',
  youtubeApiKey: '',
  // Kategorite e lejuara per Twitch dhe Kick ('*' = te gjitha)
  categories: ['Grand Theft Auto V', 'Grand Theft Auto VI'],
  // Ndez/fik platformen dhe numrin e shikuesve (nga /admin)
  platforms: { twitch: true, kick: true, tiktok: true, youtube: true },
  showViewers: { twitch: true, kick: true, tiktok: true, youtube: true },
};
let settings = { ...DEFAULT_SETTINGS, ...readJSON('settings.json', {}) };
settings.streamers = { twitch: [], kick: [], tiktok: [], youtube: [], ...settings.streamers };
settings.platforms = { ...DEFAULT_SETTINGS.platforms, ...settings.platforms };
settings.showViewers = { ...DEFAULT_SETTINGS.showViewers, ...settings.showViewers };
const PLATFORMS = ['twitch', 'kick', 'tiktok', 'youtube'];
if (!fs.existsSync(path.join(DATA_DIR, 'settings.json'))) writeJSON('settings.json', settings);

const streamersOf = p => settings.streamers[p] || [];
const enabled = () => ({
  youtube: settings.platforms.youtube !== false && streamersOf('youtube').length > 0,
  twitch: settings.platforms.twitch !== false && !!(CONFIG.TWITCH.CLIENT_ID && CONFIG.TWITCH.CLIENT_SECRET && (streamersOf('twitch').length || CONFIG.TWITCH.SCAN_ALL_GTA)),
  kick: settings.platforms.kick !== false && !!(CONFIG.KICK.CLIENT_ID && CONFIG.KICK.CLIENT_SECRET && streamersOf('kick').length),
  tiktok: settings.platforms.tiktok !== false && streamersOf('tiktok').length > 0,
});

// ---------------- NDIHMESE ----------------
function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function matchesKeywords(title) {
  const keys = settings.titleKeywords || [];
  if (!keys.length) return true;
  const t = (title || '').toLowerCase();
  return keys.some(k => t.includes(k));
}

// Kategoria/loja ku lejohet stream-i (zgjidhet te /admin -> Cilesimet)
const CAT_ALIASES = { 'gta v': 'grand theft auto v', 'gta 5': 'grand theft auto v', 'gtav': 'grand theft auto v', 'gta5': 'grand theft auto v',
  'gta vi': 'grand theft auto vi', 'gta 6': 'grand theft auto vi', 'gtavi': 'grand theft auto vi', 'gta6': 'grand theft auto vi' };
const normCat = n => { const x = String(n || '').trim().toLowerCase().replace(/\s+/g, ' '); return CAT_ALIASES[x] || x; };
function categoryOk(name) {
  const cats = settings.categories || [];
  if (!cats.length || cats.includes('*')) return true;
  const n = normCat(name);
  return !!n && cats.some(c => normCat(c) === n);
}

// Token-a OAuth (client credentials) me cache
function tokenManager(fetchToken) {
  let token = null, expires = 0;
  return {
    async get() {
      if (token && Date.now() < expires) return token;
      const data = await fetchToken();
      token = data.access_token;
      expires = Date.now() + ((data.expires_in || 3600) - 300) * 1000;
      return token;
    },
    reset() { token = null; },
  };
}

// ============================================================
//  TWITCH
// ============================================================
const TWITCH_GTA_ID = '32982';

const twitchToken = tokenManager(async () => {
  const body = new URLSearchParams({
    client_id: CONFIG.TWITCH.CLIENT_ID,
    client_secret: CONFIG.TWITCH.CLIENT_SECRET,
    grant_type: 'client_credentials',
  });
  const res = await fetch('https://id.twitch.tv/oauth2/token', { method: 'POST', body });
  if (!res.ok) throw new Error('Twitch token error ' + res.status);
  return res.json();
});

async function twitch(endpoint, retry = true) {
  const res = await fetch(`https://api.twitch.tv/helix/${endpoint}`, {
    headers: { 'Client-ID': CONFIG.TWITCH.CLIENT_ID, Authorization: `Bearer ${await twitchToken.get()}` },
  });
  if (res.status === 401 && retry) { twitchToken.reset(); return twitch(endpoint, false); }
  if (!res.ok) throw new Error('Twitch API error ' + res.status);
  return res.json();
}

// Profilet e streamerave te listes (per seksionin Offline) - rifreskohen cdo 30 min
let twitchProfiles = { updated: 0, users: [] };
async function getTwitchProfiles() {
  if (Date.now() - twitchProfiles.updated < 30 * 60 * 1000) return twitchProfiles.users;
  const users = [];
  for (const group of chunk(streamersOf('twitch'), 100)) {
    const { data } = await twitch('users?' + group.map(l => `login=${encodeURIComponent(l)}`).join('&'));
    users.push(...data);
  }
  twitchProfiles = { updated: Date.now(), users };
  return users;
}

async function fetchTwitch() {
  const raw = [];

  for (const group of chunk(streamersOf('twitch'), 100)) {
    const q = group.map(l => `user_login=${encodeURIComponent(l)}`).join('&');
    const { data } = await twitch(`streams?${q}&first=100`);
    raw.push(...data.filter(s => categoryOk(s.game_name) && matchesKeywords(s.title)));
  }

  if (CONFIG.TWITCH.SCAN_ALL_GTA && (settings.titleKeywords || []).length) {
    let cursor = '';
    for (let page = 0; page < 10; page++) {
      const { data, pagination } = await twitch(
        `streams?game_id=${TWITCH_GTA_ID}&first=100${cursor ? `&after=${cursor}` : ''}`
      );
      raw.push(...data.filter(s => matchesKeywords(s.title)));
      if (!pagination?.cursor) break;
      cursor = pagination.cursor;
    }
  }

  const unique = [...new Map(raw.map(s => [s.user_id, s])).values()];

  const avatars = {};
  for (const group of chunk(unique.map(s => s.user_id), 100)) {
    const { data } = await twitch('users?' + group.map(id => `id=${id}`).join('&'));
    data.forEach(u => (avatars[u.id] = u.profile_image_url));
  }

  const profiles = await getTwitchProfiles().catch(() => []);
  const roster = profiles.map(u => ({
    platform: 'twitch', name: u.display_name, login: u.login,
    avatar: u.profile_image_url, url: `https://twitch.tv/${u.login}`,
  }));

  const live = unique.map(s => ({
    platform: 'twitch',
    login: s.user_login,
    name: s.user_name,
    title: s.title,
    viewers: s.viewer_count,
    startedAt: s.started_at,
    thumbnail: s.thumbnail_url.replace('{width}', '640').replace('{height}', '360'),
    avatar: avatars[s.user_id] || '',
    url: `https://twitch.tv/${s.user_login}`,
  }));
  return { live, roster };
}

// ============================================================
//  KICK (API zyrtar: api.kick.com/public)
// ============================================================
const kickToken = tokenManager(async () => {
  const body = new URLSearchParams({
    client_id: CONFIG.KICK.CLIENT_ID,
    client_secret: CONFIG.KICK.CLIENT_SECRET,
    grant_type: 'client_credentials',
  });
  const res = await fetch('https://id.kick.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!res.ok) throw new Error('Kick token error ' + res.status);
  return res.json();
});

async function kick(endpoint, retry = true) {
  const res = await fetch(`https://api.kick.com/public/${endpoint}`, {
    headers: { Authorization: `Bearer ${await kickToken.get()}`, Accept: 'application/json' },
  });
  if (res.status === 401 && retry) { kickToken.reset(); return kick(endpoint, false); }
  if (!res.ok) throw new Error('Kick API error ' + res.status);
  return res.json();
}

const kickAvatarMemory = {};
let kickUsersFetched = 0;

async function fetchKick() {
  // 1) Merr kanalet sipas slug-ut -> kush eshte live
  const live = [];
  const channels = [];
  for (const group of chunk(streamersOf('kick'), 50)) {
    const { data } = await kick('v1/channels?' + group.map(s => `slug=${encodeURIComponent(s)}`).join('&'));
    (data || []).forEach(c => {
      channels.push(c);
      if (c.stream?.is_live && categoryOk(c.category?.name) && matchesKeywords(c.stream_title)) live.push(c);
    });
  }

  // 2) Merr foton e profilit per ata qe jane live
  const avatars = {};
  if (live.length) try {
    for (const group of chunk(live.map(c => c.broadcaster_user_id), 100)) {
      const { data } = await kick('v1/users/livestreams?' + group.map(id => `user_id=${id}`).join('&'));
      (data || []).forEach(l => (avatars[l.broadcaster_user?.id] = l.broadcaster_user?.profile_picture));
    }
  } catch (e) { /* avatar-i eshte opsional */ }

  // Fotot e profilit per te gjithe kanalet (edhe offline), rifreskohen cdo ore
  if (Date.now() - kickUsersFetched > 60 * 60 * 1000 && channels.length) try {
    for (const group of chunk(channels.map(c => c.broadcaster_user_id).filter(Boolean), 50)) {
      const { data } = await kick('v1/users?' + group.map(id => `id=${id}`).join('&'));
      (data || []).forEach(u => u.profile_picture && (kickAvatarMemory[u.user_id] = u.profile_picture));
    }
    kickUsersFetched = Date.now();
  } catch (e) { kickUsersFetched = Date.now() - 50 * 60 * 1000; /* provo perseri pas 10 min */ }

  // Avatar-et e kanaleve offline ruhen nga hera e fundit qe kane qene live
  Object.entries(avatars).forEach(([id, url]) => url && (kickAvatarMemory[id] = url));
  const roster = channels.map(c => ({
    platform: 'kick', name: c.slug, login: c.slug,
    avatar: kickAvatarMemory[c.broadcaster_user_id] || '', url: `https://kick.com/${c.slug}`,
  }));

  return { roster, live: live.map(c => ({
    platform: 'kick',
    login: c.slug,
    name: c.slug,
    title: c.stream_title,
    viewers: c.stream.viewer_count || 0,
    startedAt: c.stream.start_time,
    thumbnail: c.stream.thumbnail || '',
    avatar: avatars[c.broadcaster_user_id] || '',
    url: `https://kick.com/${c.slug}`,
  })) };
}

// ============================================================
//  TIKTOK (pa API zyrtar - perdor librarine tiktok-live-connector)
// ============================================================
let TikTokLiveConnection;
async function loadTikTok() {
  if (!TikTokLiveConnection) ({ TikTokLiveConnection } = await import('tiktok-live-connector'));
  return TikTokLiveConnection;
}

const pick = (obj, ...paths) => {
  for (const p of paths) {
    const v = p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return undefined;
};

const tiktokAvatarMemory = {};
const tiktokProfileCache = {}; // username -> { at, data }
const TT_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'en-US,en;q=0.9',
  'Referer': 'https://www.tiktok.com/',
};

// TikTok kerkon nje cookie vizitori (si browser) para se te pergjigjet
let ttCookie = { value: '', at: 0 };
async function tiktokCookie() {
  if (ttCookie.value && Date.now() - ttCookie.at < 6 * 3600 * 1000) return ttCookie.value;
  try {
    const r = await fetch('https://www.tiktok.com/', { headers: { 'User-Agent': TT_HEADERS['User-Agent'], 'Accept-Language': 'en-US,en;q=0.9' }, signal: withTimeout(8000) });
    const list = typeof r.headers.getSetCookie === 'function' ? r.headers.getSetCookie() : [r.headers.get('set-cookie') || ''];
    const value = list.map(c => String(c).split(';')[0]).filter(c => /^(ttwid|tt_csrf_token|tt_chain_token|msToken)=/.test(c)).join('; ');
    if (value) ttCookie = { value, at: Date.now() };
  } catch { /* provo pa cookie */ }
  return ttCookie.value;
}

// Burimi i dyte: i njejti qe perdor faqja e TikTok-ut (jep foton, emrin, statusin live, kopertinen)
// Shenim: TikTok e fsheh numrin e shikuesve per vizitoret e pa kycur (kthen 0).
async function tiktokApiLive(username) {
  const c = tiktokProfileCache[username];
  if (c && Date.now() - c.at < 2 * 60 * 1000) return c.data;
  const q = new URLSearchParams({ aid: '1988', app_language: 'en', app_name: 'tiktok_web', device_platform: 'web_pc', sourceType: '54', uniqueId: username });
  const cookie = await tiktokCookie();
  const r = await fetch('https://www.tiktok.com/api-live/user/room/?' + q, { headers: { ...TT_HEADERS, ...(cookie ? { Cookie: cookie } : {}) }, signal: withTimeout(8000) });
  if (!r.ok) throw new Error('api-live ' + r.status);
  const j = await r.json().catch(() => null);
  if (!j) ttCookie.at = 0; // pergjigje bosh -> merr cookie te re heren tjeter
  const data = j?.data || null;
  tiktokProfileCache[username] = { at: Date.now(), data };
  return data;
}
const ttAvatar = d => pick(d || {}, 'user.avatarMedium', 'user.avatarLarger', 'user.avatarThumb') || '';

async function checkTikTokUser(username) {
  let conn = null;
  const getConn = async () => conn || (conn = new (await loadTikTok())(username, { signApiKey: CONFIG.TIKTOK.SIGN_API_KEY }));

  // 1) faqja e TikTok-ut (shpejt, pa nenshkrim)
  const api = await tiktokApiLive(username).catch(e => { console.warn(`[TikTok] ${username} api-live:`, e.message); return null; });
  const apiAvatar = ttAvatar(api);
  if (apiAvatar) tiktokAvatarMemory[username] = apiAvatar;
  const lr = api?.liveRoom || {};
  const apiLive = lr.status === 2; // 2 = live, 4 = offline

  // 2) libraria (kontroll i dyte nese faqja s'u pergjigj)
  let isLive = apiLive;
  if (!isLive) isLive = await getConn().then(c => c.fetchIsLive()).catch(() => false);
  if (!isLive) return null;

  const info = await getConn().then(c => c.fetchRoomInfo()).catch(() => ({}));
  const room = info?.data || info || {};
  const title = pick(room, 'title') || lr.title || '';
  if (!matchesKeywords(title)) return null;

  const viewers = Math.max(
    Number(pick(room, 'user_count', 'stats.user_count') || 0),
    Number(pick(lr, 'liveRoomStats.userCount') || 0),
  );
  const created = pick(room, 'create_time') || lr.startTime;
  const avatar = pick(room, 'owner.avatar_medium.url_list.0', 'owner.avatar_thumb.url_list.0') || apiAvatar || tiktokAvatarMemory[username] || '';
  if (avatar) tiktokAvatarMemory[username] = avatar;

  return {
    platform: 'tiktok',
    login: username,
    name: pick(room, 'owner.nickname') || pick(api || {}, 'user.nickname') || username,
    title,
    viewers: viewers || null, // null = TikTok nuk e tregon numrin (fshihet ne faqe, jo "0")
    startedAt: created ? new Date(Number(created) * 1000).toISOString() : null,
    thumbnail: pick(room, 'cover.url_list.0', 'cover.url') || lr.coverUrl || pick(lr, 'squareCoverImg') || '',
    avatar,
    url: `https://www.tiktok.com/@${username}/live`,
  };
}

// Fotot e profilit per streamerat TikTok qe jane offline (rifreskohen cdo 6 ore)
const ttProfileFetched = {};
async function refreshTikTokAvatars(names) {
  const due = names.filter(u => !tiktokAvatarMemory[u] || Date.now() - (ttProfileFetched[u] || 0) > 6 * 3600 * 1000).slice(0, 10);
  for (const u of due) {
    ttProfileFetched[u] = Date.now();
    try { const a = ttAvatar(await tiktokApiLive(u)); if (a) tiktokAvatarMemory[u] = a; } catch { /* provo me vone */ }
  }
}

async function fetchTikTok() {
  const out = [];
  // Kontrollo 5 njeheresh qe mos te bllokohemi nga TikTok
  for (const group of chunk(streamersOf('tiktok'), 5)) {
    const results = await Promise.allSettled(group.map(checkTikTokUser));
    results.forEach((r, i) => {
      if (r.status === 'fulfilled' && r.value) out.push(r.value);
      else if (r.status === 'rejected') console.warn(`[TikTok] ${group[i]}:`, r.reason?.message || r.reason);
    });
  }
  const liveSet = new Set(out.map(s => s.login));
  await refreshTikTokAvatars(streamersOf('tiktok').filter(u => !liveSet.has(u)));
  const roster = streamersOf('tiktok').map(u => ({
    platform: 'tiktok', name: u, login: u,
    avatar: tiktokAvatarMemory[u] || '', url: `https://www.tiktok.com/@${u}`,
  }));
  return { live: out, roster };
}

// ============================================================
//  YOUTUBE (pa celes: lexon faqen youtube.com/@kanali/live)
//  Opsionale: YouTube API key per numrin e shikuesve
// ============================================================
const YT_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  'Accept-Language': 'en-US,en;q=0.9',
  Cookie: 'SOCS=CAI; CONSENT=YES+cb', // anashkalon faqen e pelqimit ne Evrope
};
const ytAvatarMemory = {};
const decodeHtml = s => String(s || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');

async function checkYouTubeChannel(handle) {
  const res = await fetch(`https://www.youtube.com/@${encodeURIComponent(handle)}/live`, { headers: YT_HEADERS, redirect: 'follow' });
  if (res.status === 404) throw new Error('kanali nuk u gjet');
  if (!res.ok) throw new Error('YouTube ' + res.status);
  const html = await res.text();

  const avatar = (html.match(/"avatar":\{"thumbnails":\[\{"url":"([^"]+)"/) || [])[1];
  if (avatar) ytAvatarMemory[handle] = avatar.replace(/\\u0026/g, '&');
  const channelName = decodeHtml((html.match(/"ownerChannelName":"([^"]+)"/) || html.match(/<meta property="og:title" content="([^"]+)"/) || [])[1]) || handle;

  // Kanali eshte live vetem kur /live con te nje video qe po transmetohet tani
  const videoId = (html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})"/) || [])[1];
  const isLive = /"isLiveNow":true/.test(html) || /"isLive":true/.test(html);
  if (!videoId || !isLive) return { live: null, name: channelName };

  const title = decodeHtml((html.match(/<meta name="title" content="([^"]*)"/) || html.match(/<meta property="og:title" content="([^"]*)"/) || [])[1]);
  const startedAt = (html.match(/"startTimestamp":"([^"]+)"/) || [])[1] || null;
  return {
    name: channelName,
    live: {
      platform: 'youtube', login: handle, videoId,
      name: channelName, title, viewers: null, startedAt, // null = s'dihet (pa API key)
      thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault_live.jpg`,
      avatar: ytAvatarMemory[handle] || '',
      url: `https://www.youtube.com/watch?v=${videoId}`,
    },
  };
}

async function fetchYouTube() {
  const live = [], names = {};
  for (const group of chunk(streamersOf('youtube'), 4)) {
    const results = await Promise.allSettled(group.map(checkYouTubeChannel));
    results.forEach((r, i) => {
      if (r.status === 'fulfilled') {
        names[group[i]] = r.value.name;
        if (r.value.live && matchesKeywords(r.value.live.title)) live.push(r.value.live);
      } else console.warn(`[YouTube] ${group[i]}:`, r.reason?.message || r.reason);
    });
  }

  // Me API key: numri i shikuesve dhe ora e fillimit (1 njesi kuote per 50 video)
  if (live.length && settings.youtubeApiKey) {
    try {
      const ids = live.map(l => l.videoId).join(',');
      const r = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=liveStreamingDetails&id=${ids}&key=${encodeURIComponent(settings.youtubeApiKey)}`);
      if (r.ok) {
        const { items } = await r.json();
        (items || []).forEach(it => {
          const l = live.find(x => x.videoId === it.id);
          if (!l) return;
          l.viewers = Number(it.liveStreamingDetails?.concurrentViewers || 0);
          l.startedAt = it.liveStreamingDetails?.actualStartTime || l.startedAt;
        });
      } else console.warn('[YouTube API]', r.status);
    } catch (e) { console.warn('[YouTube API]', e.message); }
  }

  const roster = streamersOf('youtube').map(h => ({
    platform: 'youtube', name: names[h] || h, login: h,
    avatar: ytAvatarMemory[h] || '', url: `https://www.youtube.com/@${h}`,
  }));
  return { live, roster };
}

// ============================================================
//  CACHE + API
// ============================================================
let cache = { updated: 0, streams: [], offline: [], errors: {} };
let refreshing = null;

// ============================================================
//  DISCORD WEBHOOKS (njoftime automatike)
// ============================================================
const WEBHOOK_RE = /^https:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]+$/;
const PLAT_INFO = {
  twitch: { label: 'Twitch', color: 0x9146ff }, kick: { label: 'Kick', color: 0x53fc18 },
  tiktok: { label: 'TikTok', color: 0xfe2c55 }, youtube: { label: 'YouTube', color: 0xff0033 },
};
const siteUrl = () => (process.env.SITE_URL || 'https://undergroundrp.tech').replace(/\/+$/, '');

async function sendWebhook(kind, payload) {
  const url = settings.webhooks?.[kind];
  if (!url) return false;
  try {
    const r = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'Underground RP', allowed_mentions: { parse: [] }, ...payload }),
    });
    if (!r.ok) console.warn('[webhook]', kind, r.status);
    return r.ok;
  } catch (e) { console.warn('[webhook]', kind, e.message); return false; }
}

// Teksti nga perdoruesit (emra, tituj, aplikime) shkon ne Discord pa markdown, pa linqe te maskuara dhe pa @ping
const dcSafe = (v, max = 1000) => String(v ?? '').slice(0, max)
  .replace(/[\\`*_~|>\[\]()#-]/g, '\\$&').replace(/@/g, '@\u200b').replace(/<(?=[@#:a])/g, '<\u200b').replace(/:\/\//g, ':\u200b//');

// Teksti i njoftimit te live-it: {name} {platform} {title} {link}
function liveMessage(st, platformLabel) {
  const tpl = settings.webhookLiveText || '**{name}** po bën stream në **{platform}**! {link}';
  const txt = tpl.replace(/\{name\}/g, () => dcSafe(st.name, 80)).replace(/\{platform\}/g, () => platformLabel)
    .replace(/\{title\}/g, () => dcSafe(st.title, 150)).replace(/\{link\}/g, () => st.url);
  return ((settings.webhookEveryone ? '@everyone ' : '') + txt).slice(0, 1900);
}

// Njofto kur nje streamer hap live (vetem nje here per live, edhe pas restart-it)
let announced = readJSON('announced.json', {});
function announceNewLives(streams) {
  if (!settings.webhooks?.live) return;
  const now = Date.now();
  let changed = false;
  for (const st of streams) {
    const key = st.platform + ':' + st.login;
    const last = announced[key] || 0;
    announced[key] = now; changed = true;
    if (now - last < 30 * 60 * 1000) continue; // ishte live se fundmi -> mos e njofto perseri
    const info = PLAT_INFO[st.platform] || { label: st.platform, color: 0x7dff8a };
    const fields = [];
    if (st.viewers != null && settings.showViewers?.[st.platform] !== false) fields.push({ name: 'Shikues', value: String(st.viewers), inline: true });
    sendWebhook('live', {
      content: liveMessage(st, info.label),
      allowed_mentions: { parse: settings.webhookEveryone ? ['everyone'] : [] },
      embeds: [{
        title: `🔴 ${String(st.name).slice(0, 80)} është LIVE në ${info.label}`,
        url: st.url, description: st.title ? dcSafe(st.title, 300) : undefined, color: info.color,
        thumbnail: st.avatar ? { url: st.avatar } : undefined,
        image: st.thumbnail && /^https:/.test(st.thumbnail) ? { url: st.thumbnail + (st.platform === 'twitch' ? `?t=${now}` : '') } : undefined,
        fields, footer: { text: 'Underground RP · ' + siteUrl().replace(/^https?:\/\//, '') + '/streamers' },
        timestamp: new Date().toISOString(),
      }],
    });
  }
  // pastro te vjetrat
  for (const k of Object.keys(announced)) if (now - announced[k] > 24 * 3600 * 1000) { delete announced[k]; changed = true; }
  if (changed) writeJSON('announced.json', announced);
}

// ============================================================
//  MATJA E KOHES LIVE (per giveaway / leaderboard)
//  Cdo minute shtohet koha per cdo streamer qe eshte live.
// ============================================================
let stats = readJSON('stats.json', null) || { since: new Date().toISOString(), lastTick: 0, totals: {} };
// Kujtesa e fotove te profilit (platform:login -> url); fillon me ato qe njihen nga koha live
const avatarMem = readJSON('avatars.json', {});
for (const t of Object.values(stats.totals || {})) if (t.avatar && !avatarMem[t.platform + ':' + t.login]) avatarMem[t.platform + ':' + t.login] = t.avatar;

function trackLiveTime(streams) {
  const now = Date.now();
  // nese serveri ka qene i fikur, mos numero kohen e humbur (max 3 min per tik)
  const elapsed = stats.lastTick ? Math.min(now - stats.lastTick, 3 * 60 * 1000) : 0;
  stats.lastTick = now;
  for (const st of streams) {
    const key = st.platform + ':' + st.login;
    const t = stats.totals[key] ||= { platform: st.platform, login: st.login, name: st.name, seconds: 0, sessions: 0, lastLive: 0 };
    t.name = st.name || t.name;
    if (st.avatar) t.avatar = st.avatar;
    if (now - (t.lastLive || 0) > 10 * 60 * 1000) t.sessions++; // live i ri
    t.seconds += Math.round(elapsed / 1000);
    t.lastLive = now;
  }
  writeJSON('stats.json', stats);
}
function leaderboard() {
  return Object.values(stats.totals)
    .filter(t => settings.platforms?.[t.platform] !== false)
    .sort((a, b) => b.seconds - a.seconds);
}
// Kontrollo cdo minute edhe kur s'ka vizitore, qe koha te matet sakte
setInterval(() => {
  if (!refreshing) refreshing = refresh().catch(e => console.warn('[refresh]', e.message)).finally(() => (refreshing = null));
}, 60 * 1000);

async function refresh() {
  const on = enabled();
  const jobs = {
    twitch: on.twitch ? fetchTwitch() : Promise.resolve({ live: [], roster: [] }),
    kick: on.kick ? fetchKick() : Promise.resolve({ live: [], roster: [] }),
    tiktok: on.tiktok ? fetchTikTok() : Promise.resolve({ live: [], roster: [] }),
    youtube: on.youtube ? fetchYouTube() : Promise.resolve({ live: [], roster: [] }),
  };
  const keys = Object.keys(jobs);
  const results = await Promise.allSettled(Object.values(jobs));

  const streams = [];
  const roster = [];
  const errors = {};
  results.forEach((r, i) => {
    const platform = keys[i];
    if (r.status === 'fulfilled') { streams.push(...r.value.live); roster.push(...r.value.roster); }
    else {
      errors[platform] = r.reason?.message || 'error';
      console.error(`[${platform}]`, r.reason);
      // mbaj te dhenat e vjetra te asaj platforme nese deshtoi
      streams.push(...cache.streams.filter(s => s.platform === platform));
      roster.push(...cache.offline.filter(s => s.platform === platform));
    }
  });

  // Fotot ruhen ne disk: kur streameri eshte offline (Kick/TikTok s'e japin), perdoret e fundit qe u pa
  let avChanged = false;
  for (const s of [...streams, ...roster]) {
    const k = s.platform + ':' + s.login;
    if (s.avatar && /^https:\/\//.test(s.avatar) && avatarMem[k] !== s.avatar) { avatarMem[k] = s.avatar; avChanged = true; }
  }
  for (const s of [...streams, ...roster]) if (!s.avatar) s.avatar = avatarMem[s.platform + ':' + s.login] || '';
  if (avChanged) writeJSON('avatars.json', avatarMem);

  const liveKeys = new Set(streams.map(s => s.platform + ':' + s.login));
  const offline = roster
    .filter(s => !liveKeys.has(s.platform + ':' + s.login))
    .sort((a, b) => a.name.localeCompare(b.name));

  announceNewLives(streams.filter(st => settings.platforms?.[st.platform] !== false));
  trackLiveTime(streams);
  cache = { updated: Date.now(), streams: streams.sort((a, b) => (b.viewers || 0) - (a.viewers || 0)), offline, errors };
}

app.get('/api/live', async (req, res) => {
  if (Date.now() - cache.updated > CONFIG.CACHE_SECONDS * 1000) {
    refreshing ||= refresh().finally(() => (refreshing = null));
    await refreshing;
  }
  // Fshih platformat e fikura dhe shikuesit kur admini i ka fikur
  const isOn = p => settings.platforms[p] !== false;
  const streams = cache.streams.filter(s => isOn(s.platform))
    .map(s => settings.showViewers[s.platform] === false ? { ...s, viewers: null } : s);
  const offline = cache.offline.filter(s => isOn(s.platform));
  const by = p => streams.filter(s => s.platform === p).length;
  res.json({
    count: streams.length,
    totalViewers: streams.reduce((a, s) => a + (s.viewers || 0), 0),
    // fshih kutine 'shikues' kur asnje live s'ka numer (p.sh. vetem TikTok, qe e fsheh)
    showTotalViewers: PLATFORMS.some(p => isOn(p) && settings.showViewers[p] !== false) && (!streams.length || streams.some(s => s.viewers != null)),
    enabled: Object.fromEntries(PLATFORMS.map(p => [p, isOn(p)])),
    platforms: Object.fromEntries(PLATFORMS.map(p => [p, by(p)])),
    updated: cache.updated,
    streams,
    offline,
  });
});

// ============================================================
//  STATUSI I SERVERIT FIVEM (lojtaret online)
// ============================================================
let statusCache = { updated: 0, data: { online: false } };
const withTimeout = (ms) => { const c = new AbortController(); setTimeout(() => c.abort(), ms); return c.signal; };

// Lexon numrin e lojtareve direkt nga serveri FiveM (dynamic.json)
async function readDynamic(base) {
  const r = await fetch(base.replace(/\/+$/, '') + '/dynamic.json', { signal: withTimeout(6000) });
  if (!r.ok) throw new Error('dynamic.json ' + r.status);
  const d = await r.json();
  return { online: true, players: Number(d.clients ?? 0), maxPlayers: Number(d.sv_maxclients ?? d.svMaxclients ?? 0) };
}

let serverBase = ''; // adresa e serverit qe u gjet se fundmi (per players.json)

async function fetchServerStatus() {
  const errors = [];
  // 1) IP:Port e vendosur te /admin (menyra me e sigurt)
  if (settings.fivemAddress) {
    try { const r = await readDynamic('http://' + settings.fivemAddress); serverBase = 'http://' + settings.fivemAddress; return r; }
    catch (e) { errors.push('IP: ' + e.message); }
  }
  if (settings.cfxCode) {
    // 2) cfx.re/join/KODI -> adresa e vertete e serverit
    try {
      const r = await fetch(`https://cfx.re/join/${encodeURIComponent(settings.cfxCode)}`, { redirect: 'manual', signal: withTimeout(6000) });
      const url = r.headers.get('x-citizenfx-url');
      if (url) { const st = await readDynamic(url); serverBase = url; return st; }
      errors.push('cfx.re: ' + r.status);
    } catch (e) { errors.push('cfx.re: ' + e.message); }
    // 3) Lista publike e FiveM
    try {
      const r = await fetch(`https://servers-frontend.fivem.net/api/servers/single/${encodeURIComponent(settings.cfxCode)}`, {
        headers: { 'User-Agent': 'Mozilla/5.0 (UndergroundRP website)', Accept: 'application/json' }, signal: withTimeout(6000),
      });
      if (!r.ok) throw new Error(String(r.status));
      const { Data } = await r.json();
      return { online: true, players: Number(Data.clients ?? 0) || 0, maxPlayers: Number(Data.sv_maxclients ?? Data.svMaxclients ?? 0) || 0 };
    } catch (e) { errors.push('fivem list: ' + e.message); }
  }
  throw new Error(errors.join(' | ') || 'mungon IP dhe kodi cfx');
}

// ---------- Lista e lojtareve online ----------
// Vetem ID, emri dhe ping. Identifikuesit (license, steam, discord, IP) NUK dergohen kurre.
let playersCache = { updated: 0, list: [], ok: false };
app.get('/api/players', async (req, res) => {
  // Lista fshihet si parazgjedhje; admini e ndez te Cilesimet
  if (settings.showPlayers !== true || settings.showStatus !== true) return res.json({ enabled: false, players: [] });
  if (Date.now() - playersCache.updated > 30 * 1000) {
    playersCache.updated = Date.now();
    try {
      if (!serverBase) await fetchServerStatus().catch(() => {});
      if (!serverBase) throw new Error('serveri nuk u gjet');
      const r = await fetch(serverBase.replace(/\/+$/, '') + '/players.json', { signal: withTimeout(6000) });
      if (!r.ok) throw new Error('players.json ' + r.status);
      const raw = await r.json();
      playersCache.list = (Array.isArray(raw) ? raw : [])
        .map(p => ({ id: Number(p.id) || 0, name: String(p.name || 'Lojtar').replace(/\^\d/g, '').slice(0, 40), ping: Number(p.ping) || 0 }))
        .sort((a, b) => a.id - b.id);
      playersCache.ok = true;
    } catch (e) {
      console.warn('[players]', e.message);
      playersCache.ok = false;
    }
  }
  res.json({ enabled: true, ok: playersCache.ok, players: playersCache.list });
});

async function getStatus() {
  if (Date.now() - statusCache.updated > 60 * 1000) {
    try { statusCache.data = await fetchServerStatus(); statusCache.error = ''; }
    catch (e) { console.warn('[status]', e.message); statusCache.data = { online: false }; statusCache.error = e.message; }
    statusCache.updated = Date.now();
  }
  return statusCache.data;
}
app.get('/api/status', async (req, res) => {
  // Statusi fshihet derisa admini ta ndeze (p.sh. kur porti nuk eshte i hapur)
  if (settings.showStatus !== true) return res.json({ enabled: false });
  res.json({ enabled: true, ...(await getStatus()) });
});
// Admini e kontrollon IP-ne edhe kur statusi eshte i fshehur
app.get('/api/admin/status-check', requireAdmin, async (req, res) => { res.json(await getStatus()); });

// ============================================================
//  KONFIGURIMI PUBLIK I FAQES (/config.js)
// ============================================================
app.get('/config.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'no-cache');
  res.send('window.SITE = ' + JSON.stringify({
    name: 'Underground RP',
    discord: settings.discord || '#',
    cfxCode: settings.cfxCode || '',
  }) + ';');
});

// ============================================================
//  RREGULLAT
// ============================================================
// Rregullorja zyrtare (seed/rules.json) futet vetem nje here per cdo version te ri
const RULES_SEED_VERSION = 2;
if ((settings.rulesSeed || 0) < RULES_SEED_VERSION) {
  try {
    const seed = JSON.parse(fs.readFileSync(path.join(__dirname, 'seed', 'rules.json'), 'utf8'));
    writeJSON('rules.json', seed);
    settings.rulesSeed = RULES_SEED_VERSION;
    writeJSON('settings.json', settings);
    console.log('Rregullorja zyrtare u ngarkua (v' + RULES_SEED_VERSION + ')');
  } catch (e) { console.warn('[rules seed]', e.message); }
}
let rules = readJSON('rules.json', []);
app.get('/api/rules', (req, res) => res.json(rules));

// ============================================================
//  DYQANI - TEBEX (paketat lexohen nga Tebex Headless API)
// ============================================================
let shopCache = { updated: 0, key: '', data: null };

app.get('/api/shop', async (req, res) => {
  const token = settings.tebexToken;
  if (!token) return res.json({ open: false, categories: [] });

  if (shopCache.key !== token || Date.now() - shopCache.updated > 5 * 60 * 1000) {
    try {
      const r = await fetch(`https://headless.tebex.io/api/accounts/${encodeURIComponent(token)}/categories?includePackages=1`,
        { headers: { Accept: 'application/json' } });
      if (!r.ok) throw new Error('Tebex ' + r.status);
      const { data } = await r.json();
      const store = (settings.tebexStoreUrl || '').replace(/\/+$/, '');
      shopCache.data = (data || []).map(c => ({
        name: c.name,
        packages: (c.packages || []).map(p => ({
          id: p.id,
          name: p.name,
          description: String(p.description || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 220),
          image: p.image || '',
          price: p.total_price ?? p.base_price ?? 0,
          currency: p.currency || 'EUR',
          url: store ? `${store}/package/${p.id}` : '',
        })),
      })).filter(c => c.packages.length);
      shopCache.updated = Date.now();
      shopCache.key = token;
    } catch (e) {
      console.warn('[tebex]', e.message);
      if (!shopCache.data) return res.json({ open: false, categories: [] });
    }
  }
  res.json({ open: shopCache.data.length > 0, storeUrl: settings.tebexStoreUrl || '', categories: shopCache.data });
});

// ============================================================
//  PANELI I ADMINIT
// ============================================================
// ---------- Fjalekalimi i adminit ruhet i koduar (scrypt) ----------
// Nese te .env eshte shkruar si tekst, ne nisje kodohet automatikisht dhe .env perditesohet.
const SCRYPT = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
const scryptAsync = (pw, salt) => new Promise((ok, fail) => crypto.scrypt(String(pw), salt, 64, SCRYPT, (e, k) => (e ? fail(e) : ok(k))));
let ADMIN_HASH = null; // { salt: Buffer, key: Buffer }
async function setupAdminPassword() {
  const raw = String(process.env.ADMIN_PASSWORD || '').trim();
  if (!raw) return console.warn('[siguri] ADMIN_PASSWORD nuk eshte vendosur, /admin nuk punon.');
  const m = raw.match(/^scrypt:([0-9a-f]{32}):([0-9a-f]{128})$/);
  if (m) { ADMIN_HASH = { salt: Buffer.from(m[1], 'hex'), key: Buffer.from(m[2], 'hex') }; return; }
  const salt = crypto.randomBytes(16);
  const key = await scryptAsync(raw, salt);
  ADMIN_HASH = { salt, key };
  try {
    const envPath = path.join(__dirname, '.env');
    const txt = fs.readFileSync(envPath, 'utf8');
    if (/^ADMIN_PASSWORD=.*$/m.test(txt)) {
      fs.writeFileSync(envPath, txt.replace(/^ADMIN_PASSWORD=.*$/m, `ADMIN_PASSWORD=scrypt:${salt.toString('hex')}:${key.toString('hex')}`), { mode: 0o600 });
      console.log('[siguri] Fjalekalimi i adminit u kodua dhe u ruajt ne .env');
    }
  } catch (e) { console.warn('[siguri] .env nuk u perditesua:', e.message); }
}
setupAdminPassword().catch(e => console.error('[siguri]', e.message));
async function checkAdminPassword(pw) {
  if (!ADMIN_HASH) return false;
  const k = await scryptAsync(String(pw || '').slice(0, 200), ADMIN_HASH.salt);
  return crypto.timingSafeEqual(k, ADMIN_HASH.key);
}

const sessions = new Map(); // token -> skadimi
const loginAttempts = new Map(); // ip -> { n, until }
function getCookie(req, name) {
  const m = (req.headers.cookie || '').match(new RegExp('(?:^|; )' + name + '=([^;]+)'));
  if (!m) return null;
  try { return decodeURIComponent(m[1]); } catch { return null; }
}
function requireAdmin(req, res, next) {
  const t = getCookie(req, 'ugrp_admin');
  const exp = t && sessions.get(t);
  if (exp && exp > Date.now()) return next();
  if (t) sessions.delete(t);
  res.status(401).json({ error: 'Duhet të hysh si admin.' });
}

app.post('/api/admin/login', async (req, res) => {
  const ip = req.ip;
  const a = loginAttempts.get(ip) || { n: 0, until: 0 };
  if (a.until > Date.now()) return res.status(429).json({ error: 'Shumë tentativa. Provo pas 15 minutash.' });
  if (!ADMIN_HASH) return res.status(500).json({ error: 'ADMIN_PASSWORD nuk është vendosur te .env' });

  let ok = false;
  try { ok = await checkAdminPassword(req.body?.password); } catch { ok = false; }
  if (!ok) {
    a.n++; a.t = Date.now();
    if (a.n >= 5) { a.n = 0; a.until = Date.now() + 15 * 60 * 1000; audit(req, 'HYRJE E BLLOKUAR', '5 fjalëkalime të gabuara, 15 min'); }
    else audit(req, 'Fjalëkalim i gabuar');
    loginAttempts.set(ip, a);
    return setTimeout(() => res.status(401).json({ error: 'Fjalëkalimi është gabim.' }), 600);
  }
  loginAttempts.delete(ip);
  audit(req, 'Hyrje në panel');
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now() + 12 * 60 * 60 * 1000);
  res.set('Set-Cookie', `ugrp_admin=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${req.secure ? '; Secure' : ''}`);
  res.json({ ok: true });
});

app.post('/api/admin/logout', (req, res) => {
  sessions.delete(getCookie(req, 'ugrp_admin'));
  audit(req, 'Dalje nga paneli');
  res.set('Set-Cookie', 'ugrp_admin=; Path=/; Max-Age=0');
  res.json({ ok: true });
});

// Sekretet nuk dergohen kurre te browser-i, vetem nese jane vendosur
const SECRET_KEYS = ['twitchClientSecret', 'kickClientSecret'];
const discordLoginOn = () => !!(settings.discordClientId && settings.discordClientSecret);
function publicSettings() {
  const out = { ...settings };
  for (const k of SECRET_KEYS) { out[k] = ''; out[k + 'Set'] = !!(settings[k] || process.env[k === 'twitchClientSecret' ? 'TWITCH_CLIENT_SECRET' : 'KICK_CLIENT_SECRET']); }
  out.twitchClientId = settings.twitchClientId || process.env.TWITCH_CLIENT_ID || '';
  out.kickClientId = settings.kickClientId || process.env.KICK_CLIENT_ID || '';
  out.youtubeApiKeySet = !!settings.youtubeApiKey; out.youtubeApiKey = '';
  out.webhooksSet = Object.fromEntries(['live', 'news', 'applications', 'shop', 'spin'].map(k => [k, !!settings.webhooks?.[k]]));
  delete out.webhooks;
  out.discordClientSecret = ''; out.discordClientSecretSet = !!settings.discordClientSecret;
  out.tebexWebhookSecret = ''; out.tebexWebhookSecretSet = !!settings.tebexWebhookSecret;
  out.tebexWebhookUrl = siteUrl() + '/api/tebex/webhook';
  out.discordRedirect = siteUrl() + '/auth/discord/callback';
  out.errors = cache.errors || {};
  out.statusError = statusCache.error || '';
  out.status = statusCache.data;
  return out;
}
app.get('/api/admin/settings', requireAdmin, (req, res) => res.json(publicSettings()));

const cleanName = v => String(v || '').trim().toLowerCase().replace(/^@/, '').replace(/^(https?:\/\/)?(www\.|m\.)?[a-z0-9-]+\.[a-z]{2,}\/@?/, '').replace(/\/.*$/, '');
const validName = v => /^[a-z0-9_.-]{2,40}$/.test(v);

app.put('/api/admin/settings', requireAdmin, (req, res) => {
  const b = req.body || {};
  const next = { ...settings };

  if (b.discord !== undefined) {
    const d = String(b.discord).trim();
    if (d && !/^https:\/\/(discord\.gg|discord\.com\/invite)\/[\w-]+$/.test(d))
      return res.status(400).json({ error: 'Linku i Discord duhet të jetë si https://discord.gg/abc123' });
    next.discord = d;
  }
  if (b.cfxCode !== undefined) {
    const c = String(b.cfxCode).trim().replace(/^.*join\//, '');
    if (c && !/^[a-z0-9]{4,12}$/i.test(c)) return res.status(400).json({ error: 'Kodi cfx duhet të jetë si pgggd68' });
    next.cfxCode = c;
  }
  if (b.fivemAddress !== undefined) {
    const a = String(b.fivemAddress).trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (a && !/^[a-z0-9.-]+:\d{2,5}$/i.test(a)) return res.status(400).json({ error: 'IP e serverit duhet të jetë si 123.45.67.89:30120' });
    next.fivemAddress = a;
  }
  if (typeof b.showPlayers === 'boolean') next.showPlayers = b.showPlayers;
  if (typeof b.showStatus === 'boolean') next.showStatus = b.showStatus;
  if (typeof b.applicationsOpen === 'boolean') next.applicationsOpen = b.applicationsOpen;
  if (b.webhookLiveText !== undefined) next.webhookLiveText = String(b.webhookLiveText).trim().slice(0, 300).replace(/@(everyone|here)/g, '$1');
  if (typeof b.webhookEveryone === 'boolean') next.webhookEveryone = b.webhookEveryone;
  if (typeof b.discordLoginRequired === 'boolean') next.discordLoginRequired = b.discordLoginRequired;
  for (const k of ['discordClientId', 'discordGuildId']) {
    if (b[k] === undefined) continue;
    const v = String(b[k]).trim();
    if (v && !/^\d{15,22}$/.test(v)) return res.status(400).json({ error: k === 'discordGuildId' ? 'Server ID duhet të jetë numër (p.sh. 1260750736438857798).' : 'Discord Client ID duhet të jetë numër.' });
    next[k] = v;
  }
  if (b.discordClientSecret !== undefined) {
    const v = String(b.discordClientSecret).trim();
    if (v && !/^[\w-]{20,80}$/.test(v)) return res.status(400).json({ error: 'Discord Client Secret nuk duket i saktë.' });
    if (v) next.discordClientSecret = v;
  }
  if (b.webhooks !== undefined) {
    next.webhooks = { ...(settings.webhooks || {}) };
    for (const k of ['live', 'news', 'applications', 'shop', 'spin']) {
      const v = String(b.webhooks?.[k] ?? '').trim();
      if (!v) continue;                         // bosh = mbaj te vjetrin
      if (v === 'none') { delete next.webhooks[k]; continue; } // hiq
      if (!WEBHOOK_RE.test(v)) return res.status(400).json({ error: 'Linku i webhook-ut nuk është i saktë. Duhet të nisë me https://discord.com/api/webhooks/' });
      next.webhooks[k] = v;
    }
  }
  if (b.categories !== undefined) {
    next.categories = [...new Set([].concat(b.categories).map(c => String(c).trim()).filter(Boolean))].slice(0, 20).map(c => c.slice(0, 60));
  }
  if (typeof b.showLeaderboard === 'boolean') next.showLeaderboard = b.showLeaderboard;
  if (b.titleKeywords !== undefined) {
    next.titleKeywords = [].concat(b.titleKeywords).map(k => String(k).trim().toLowerCase()).filter(Boolean).slice(0, 10);
  }
  if (b.streamers !== undefined) {
    const out = {};
    for (const p of PLATFORMS) {
      const names = [...new Set([].concat(b.streamers[p] || []).map(cleanName).filter(Boolean))];
      const bad = names.find(n => !validName(n));
      if (bad) return res.status(400).json({ error: `Username jo i saktë te ${p}: "${bad}"` });
      out[p] = names.slice(0, 300);
    }
    next.streamers = out;
  }
  for (const key of ['platforms', 'showViewers']) {
    if (b[key] === undefined) continue;
    next[key] = { ...settings[key] };
    for (const p of PLATFORMS) if (typeof b[key][p] === 'boolean') next[key][p] = b[key][p];
  }
  if (b.youtubeApiKey !== undefined) {
    const k = String(b.youtubeApiKey).trim();
    if (k && !/^[\w-]{20,60}$/.test(k)) return res.status(400).json({ error: 'YouTube API key nuk duket i saktë.' });
    if (k) next.youtubeApiKey = k;
  }
  if (b.tebexToken !== undefined) {
    const t = String(b.tebexToken).trim();
    if (t && !/^[\w-]{6,80}$/.test(t)) return res.status(400).json({ error: 'Tokeni i Tebex nuk duket i saktë.' });
    next.tebexToken = t;
  }
  if (b.tebexWebhookSecret !== undefined) {
    const v = String(b.tebexWebhookSecret).trim();
    if (v && !/^[\w-]{16,128}$/.test(v)) return res.status(400).json({ error: 'Webhook secret i Tebex nuk duket i saktë.' });
    if (v) next.tebexWebhookSecret = v;
  }
  if (b.tebexStoreUrl !== undefined) {
    const u = String(b.tebexStoreUrl).trim();
    if (u && !/^https:\/\/[\w.-]+(\/.*)?$/.test(u)) return res.status(400).json({ error: 'Linku i dyqanit duhet të nisë me https://' });
    next.tebexStoreUrl = u;
  }

  for (const k of ['twitchClientId', 'kickClientId', ...SECRET_KEYS]) {
    if (b[k] === undefined) continue;
    const v = String(b[k]).trim();
    if (!v) continue; // bosh = mbaj vleren e vjeter
    if (!/^[\w-]{8,100}$/.test(v)) return res.status(400).json({ error: 'Çelësi nuk duket i saktë: ' + k });
    next[k] = v;
  }

  // shkruaj ne regjistër CILAT fusha ndryshuan (jo vlerat, qe celesat te mos dalin)
  const changed = Object.keys(next).filter(k => JSON.stringify(next[k]) !== JSON.stringify(settings[k]));
  if (changed.length) audit(req, 'Cilësimet u ndryshuan', changed.join(', '));
  settings = next;
  writeJSON('settings.json', settings);
  twitchToken.reset(); kickToken.reset();
  // rifresko menjehere listat
  playersCache.updated = 0; serverBase = '';
  cache.updated = 0; twitchProfiles.updated = 0; shopCache.updated = 0; statusCache.updated = 0;
  res.json(publicSettings());
});

app.put('/api/admin/rules', requireAdmin, (req, res) => {
  const b = req.body;
  if (!Array.isArray(b) || b.length > 40) return res.status(400).json({ error: 'Format i gabuar.' });
  const clean = [];
  for (const c of b) {
    const title = String(c?.title || '').trim().slice(0, 80);
    if (!title) return res.status(400).json({ error: 'Çdo kategori duhet të ketë titull.' });
    const items = (Array.isArray(c.rules) ? c.rules : []).slice(0, 60)
      .map(r => [String(r?.[0] || '').trim().slice(0, 100), String(r?.[1] || '').trim().slice(0, 1000), String(r?.[2] || '').trim().slice(0, 8)])
      .filter(r => r[0] || r[1]);
    clean.push({ title, icon: String(c.icon || '').slice(0, 4), rules: items });
  }
  rules = clean;
  writeJSON('rules.json', rules);
  audit(req, 'Rregullat u ndryshuan', `${clean.length} kategori`);
  res.json(rules);
});

// ============================================================
//  NJOFTIMET / LAJMET
// ============================================================
let news = readJSON('news.json', []);
const NEWS_TYPES = ['Njoftim', 'Përditësim', 'Event'];
app.get('/api/news', (req, res) => res.json(news.slice(0, 20)));

app.get('/api/admin/news', requireAdmin, (req, res) => res.json(news));

app.put('/api/admin/news', requireAdmin, (req, res) => {
  const b = req.body;
  if (!Array.isArray(b) || b.length > 100) return res.status(400).json({ error: 'Format i gabuar.' });
  const clean = [];
  for (const n of b) {
    const title = String(n?.title || '').trim().slice(0, 120);
    const text = String(n?.text || '').trim().slice(0, 3000);
    if (!title) return res.status(400).json({ error: 'Çdo njoftim duhet të ketë titull.' });
    const date = /^\d{4}-\d{2}-\d{2}$/.test(n?.date) ? n.date : new Date().toISOString().slice(0, 10);
    clean.push({
      id: String(n?.id || crypto.randomBytes(6).toString('hex')).slice(0, 20),
      title, text, date,
      type: NEWS_TYPES.includes(n?.type) ? n.type : 'Njoftim',
    });
  }
  clean.sort((x, y) => y.date.localeCompare(x.date));
  // njofto ne Discord njoftimet e reja
  const oldIds = new Set(news.map(n => n.id));
  const TYPE_COLOR = { Njoftim: 0x7dff8a, 'Përditësim': 0x6cc4ff, Event: 0xffcc4d };
  for (const n of clean.filter(n => !oldIds.has(n.id))) {
    sendWebhook('news', { embeds: [{ title: `📢 ${n.title}`, description: n.text.slice(0, 3800) || undefined, color: TYPE_COLOR[n.type] || 0x7dff8a,
      author: { name: n.type }, url: siteUrl(), footer: { text: 'Underground RP' }, timestamp: new Date().toISOString() }] });
  }
  audit(req, 'Njoftimet u ndryshuan', `${clean.length} njoftime` + (clean.length > news.length ? ' (u shtua një)' : clean.length < news.length ? ' (u fshi një)' : ''));
  news = clean;
  writeJSON('news.json', news);
  res.json(news);
});

// ============================================================
//  LEADERBOARD (publik vetem kur admini e ndez)
// ============================================================
app.get('/api/leaderboard', (req, res) => {
  if (settings.showLeaderboard !== true) return res.json({ enabled: false, list: [] });
  res.json({
    enabled: true, since: stats.since,
    list: leaderboard().slice(0, 20).map(t => ({ platform: t.platform, name: t.name, avatar: t.avatar || '', seconds: t.seconds, sessions: t.sessions })),
  });
});
app.get('/api/admin/stats', requireAdmin, (req, res) => res.json({ since: stats.since, list: leaderboard(), showLeaderboard: settings.showLeaderboard === true }));
app.post('/api/admin/stats/reset', requireAdmin, (req, res) => {
  // ruaj nje kopje te periudhes se mbyllur
  writeJSON(`stats-${new Date().toISOString().slice(0, 10)}.json`, stats);
  stats = { since: new Date().toISOString(), lastTick: Date.now(), totals: {} };
  audit(req, 'Giveaway: periudhë e re (reset)');
  writeJSON('stats.json', stats);
  res.json({ since: stats.since, list: [] });
});

// ============================================================
//  DYQANI I ADMINIT: paketa VIP, shtepi ne shitje, te tjera
// ============================================================
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));

let shopItems = readJSON('shop.json', []);
const SHOP_CATS = ['vip', 'house', 'vehicle', 'other'];
const SHOP_STATUS = ['available', 'reserved', 'sold'];
app.get('/api/shop-items', (req, res) => res.json(shopItems.filter(i => !i.hidden)));
app.get('/api/admin/shop-items', requireAdmin, (req, res) => res.json(shopItems));

app.put('/api/admin/shop-items', requireAdmin, (req, res) => {
  const b = req.body;
  if (!Array.isArray(b) || b.length > 200) return res.status(400).json({ error: 'Format i gabuar.' });
  const clean = [];
  for (const it of b) {
    const title = String(it?.title || '').trim().slice(0, 80);
    if (!title) return res.status(400).json({ error: 'Çdo artikull duhet të ketë emër.' });
    const link = String(it?.link || '').trim();
    if (link && !/^https:\/\/[^\s]+$/.test(link)) return res.status(400).json({ error: `Linku te "${title}" duhet të nisë me https://` });
    const image = String(it?.image || '').trim();
    if (image && !/^(\/uploads\/[\w.-]+|https:\/\/[^\s"']+)$/.test(image)) return res.status(400).json({ error: `Foto te "${title}" nuk është e vlefshme.` });
    clean.push({
      id: String(it?.id || crypto.randomBytes(6).toString('hex')).slice(0, 20),
      category: SHOP_CATS.includes(it?.category) ? it.category : 'other',
      title,
      price: String(it?.price || '').trim().slice(0, 40),
      description: String(it?.description || '').trim().slice(0, 1500),
      features: [].concat(it?.features || []).map(f => String(f).trim().slice(0, 80)).filter(Boolean).slice(0, 12),
      image, link,
      status: SHOP_STATUS.includes(it?.status) ? it.status : 'available',
      hidden: it?.hidden === true,
    });
  }
  audit(req, 'Dyqani u ndryshua', `${clean.length} artikuj`);
  shopItems = clean;
  writeJSON('shop.json', shopItems);
  res.json(shopItems);
});

app.post('/api/admin/upload', requireAdmin, (req, res) => {
  const m = String(req.body?.data || '').match(/^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!m) return res.status(400).json({ error: 'Lejohen vetëm foto PNG, JPG ose WEBP.' });
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 4 * 1024 * 1024) return res.status(400).json({ error: 'Foto është shumë e madhe (max 4 MB).' });
  const name = crypto.randomBytes(8).toString('hex') + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  audit(req, 'Foto u ngarkua', name);
  res.json({ url: '/uploads/' + name });
});

// ============================================================
//  STAFF - ekipi i serverit (faqja /staff), menaxhohet nga admini
// ============================================================
let staff = readJSON('staff.json', []);
app.get('/api/staff', (req, res) => res.json(staff));
app.get('/api/admin/staff', requireAdmin, (req, res) => res.json(staff));
app.put('/api/admin/staff', requireAdmin, (req, res) => {
  const b = req.body;
  if (!Array.isArray(b) || b.length > 100) return res.status(400).json({ error: 'Format i gabuar.' });
  const clean = [];
  for (const m of b) {
    const name = String(m?.name || '').trim().slice(0, 40);
    if (!name) return res.status(400).json({ error: 'Çdo anëtar duhet të ketë emër.' });
    const role = String(m?.role || '').trim().slice(0, 30) || 'Staff';
    const image = String(m?.image || '').trim();
    if (image && !/^(\/uploads\/[\w.-]+|https:\/\/[^\s"']+)$/.test(image)) return res.status(400).json({ error: `Foto te "${name}" nuk është e vlefshme.` });
    clean.push({ id: String(m?.id || crypto.randomBytes(6).toString('hex')).slice(0, 20), name, role,
      discord: String(m?.discord || '').trim().replace(/^@/, '').slice(0, 40), note: String(m?.note || '').trim().slice(0, 160), image });
  }
  staff = clean;
  writeJSON('staff.json', staff);
  audit(req, 'Staff u ndryshua', `${clean.length} anëtarë`);
  res.json(staff);
});

app.post('/api/admin/webhook-test', requireAdmin, async (req, res) => {
  const kind = req.body?.kind;
  if (!['live', 'news', 'applications', 'shop', 'spin'].includes(kind)) return res.status(400).json({ error: 'Lloj i panjohur.' });
  if (!settings.webhooks?.[kind]) return res.status(400).json({ error: 'Ky webhook nuk është vendosur ende.' });
  const ok = await sendWebhook(kind, { embeds: [{ title: '✅ Test nga website-i', description: 'Lidhja me Discord punon. Këtu do vijnë njoftimet.', color: 0x7dff8a, footer: { text: 'Underground RP' } }] });
  ok ? res.json({ ok: true }) : res.status(502).json({ error: 'Discord-i nuk e pranoi. Kontrollo linkun e webhook-ut.' });
});

// ============================================================
//  TEBEX WEBHOOK -> njoftim ne Discord kur dikush blen
//  Tebex nenshkruan cdo njoftim: HMAC-SHA256( sha256(trupi), secret )
// ============================================================
app.post('/api/tebex/webhook', (req, res) => {
  const secret = settings.tebexWebhookSecret;
  if (!secret || !req.rawBody) return res.status(404).end();
  const got = String(req.headers['x-signature'] || '');
  const want = crypto.createHmac('sha256', secret).update(crypto.createHash('sha256').update(req.rawBody).digest('hex')).digest('hex');
  if (got.length !== want.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(want))) {
    audit(req, 'Tebex: nënshkrim i gabuar (u refuzua)');
    return res.status(403).json({ error: 'invalid signature' });
  }
  let body;
  try { body = JSON.parse(req.rawBody); } catch { return res.status(400).end(); }

  if (body.type === 'validation.webhook') return res.json({ id: body.id });

  if (body.type === 'payment.completed') {
    const sub = body.subject || {};
    const buyer = String(sub.customer?.username?.username || 'Dikush').slice(0, 40);
    const products = (Array.isArray(sub.products) ? sub.products : []).slice(0, 10)
      .map(p => `${Number(p.quantity) > 1 ? Number(p.quantity) + 'x ' : ''}${String(p.name || '').slice(0, 60)}`).filter(Boolean);
    audit(req, 'Tebex: blerje', `${buyer}: ${products.join(', ')} (${sub.transaction_id || '-'})`);
    sendWebhook('shop', { embeds: [{
      title: '🛒 Blerje e re në dyqan',
      description: `**${dcSafe(buyer, 40)}** bleu **${dcSafe(products.join(', ') || 'një paketë', 400)}**.\nFaleminderit që mbështet Underground RP! 💚`,
      color: 0x7dff8a, url: settings.tebexStoreUrl || undefined,
      footer: { text: 'Paketa jepet automatikisht në lojë' }, timestamp: new Date().toISOString(),
    }] });
  }
  res.json({ ok: true });
});

// ============================================================
//  APLIKIMET PER STREAMER
// ============================================================
let applications = readJSON('applications.json', []);
const applyLimits = new Map(); // ip -> [kohet]
const PLAT_RE = { twitch: /^[a-z0-9_]{3,25}$/, kick: /^[a-z0-9_.-]{2,40}$/, tiktok: /^[a-z0-9_.]{2,24}$/, youtube: /^[a-z0-9_.-]{3,30}$/ };

app.post('/api/apply', (req, res) => {
  if (settings.applicationsOpen === false) return res.status(403).json({ error: 'Aplikimet janë të mbyllura për momentin.' });
  const b = req.body || {};
  if (b.website) return res.json({ ok: true }); // fushe-kurth per bote
  const ip = req.ip, now = Date.now();
  const times = (applyLimits.get(ip) || []).filter(t => now - t < 3600 * 1000);
  if (times.length >= 3) return res.status(429).json({ error: 'Ke dërguar shumë aplikime. Provo pas një ore.' });

  const platform = String(b.platform || '');
  if (!PLATFORMS.includes(platform)) return res.status(400).json({ error: 'Zgjidh platformën.' });
  const username = cleanName(String(b.username || '').slice(0, 200));
  if (!PLAT_RE[platform].test(username)) return res.status(400).json({ error: 'Username-i nuk duket i saktë. Shkruaj vetëm emrin e kanalit.' });
  const user = discordUser(req);
  const mustLogin = discordLoginOn() && settings.discordLoginRequired !== false;
  if (mustLogin && !user) return res.status(401).json({ error: 'Hyr me Discord para se të aplikosh.' });
  if (user && settings.discordGuildId && !user.inGuild)
    return res.status(403).json({ error: 'Duhet të jesh anëtar i Discord-it të Underground RP për të aplikuar.' });
  const discord = user ? user.username : String(b.discord || '').trim().slice(0, 40);
  if (discord.length < 2) return res.status(400).json({ error: 'Shkruaj emrin tënd në Discord.' });
  if (user && applications.some(a => a.status === 'pending' && a.discordId === user.id))
    return res.status(400).json({ error: 'Ke tashmë një aplikim në pritje.' });
  const character = String(b.character || '').trim().slice(0, 60);
  const about = String(b.about || '').trim().slice(0, 600);
  if ((settings.streamers[platform] || []).includes(username)) return res.status(400).json({ error: 'Ky kanal është tashmë në listën e streamerave.' });
  // Nje aplikim anonim (pa Discord) nuk e bllokon dot pronarin e vertete te kanalit
  if (applications.some(a => a.status === 'pending' && a.platform === platform && a.username === username && (a.discordId || !user)))
    return res.status(400).json({ error: 'Ky kanal ka tashmë një aplikim në pritje.' });
  if (!user && applications.filter(a => a.status === 'pending' && !a.discordId).length >= 50)
    return res.status(429).json({ error: 'Ka shumë aplikime në pritje. Provo më vonë ose hyr me Discord.' });

  // A e ka lidhur kete kanal ne Discord? (Twitch, YouTube, TikTok verifikohen nga Discord-i)
  const conn = user ? (user.connections || []) : [];
  const channelVerified = conn.some(c => c.type === platform && c.verified && cleanName(c.name) === username);
  const appItem = {
    id: crypto.randomBytes(6).toString('hex'), platform, username, discord, character, about, status: 'pending', createdAt: new Date().toISOString(),
    ...(user ? { discordId: user.id, discordName: user.globalName || user.username, discordAvatar: user.avatar, inGuild: user.inGuild,
                 accountCreated: user.createdAt, connections: conn, channelVerified } : {}),
  };
  applications.unshift(appItem);
  applications = applications.slice(0, 500);
  writeJSON('applications.json', applications);
  times.push(now); applyLimits.set(ip, times);

  const info = PLAT_INFO[platform];
  sendWebhook('applications', { embeds: [{
    title: '📝 Aplikim i ri për streamer', color: info.color, url: siteUrl() + '/admin',
    fields: [
      { name: 'Platforma', value: info.label, inline: true },
      { name: 'Kanali', value: username, inline: true },
      { name: 'Discord', value: appItem.discordId ? `<@${appItem.discordId}> (${dcSafe(discord, 40)})` : dcSafe(discord, 40) + ' (pa verifikim)', inline: true },
      ...(appItem.discordId ? [{ name: 'Kanali i lidhur në Discord', value: channelVerified ? '✅ Po, i verifikuar' : '⚠️ Jo, kontrolloje', inline: true }] : []),
      ...(conn.length ? [{ name: 'Lidhjet në Discord', value: conn.map(c => `${c.verified ? '✅' : '▫️'} ${dcSafe(c.type, 20)}: ${dcSafe(c.name, 60)}`).join('\n').slice(0, 1000) }] : []),
      ...(character ? [{ name: 'Karakteri', value: dcSafe(character, 100) }] : []),
      ...(about ? [{ name: 'Rreth tij', value: dcSafe(about, 1000) }] : []),
    ],
    footer: { text: 'Prano ose refuzo te paneli i adminit' }, timestamp: appItem.createdAt,
  }] });
  res.json({ ok: true });
});

app.get('/api/apply/status', (req, res) => {
  const u = discordUser(req);
  res.json({
    open: settings.applicationsOpen !== false,
    discordLogin: discordLoginOn(),
    loginRequired: discordLoginOn() && settings.discordLoginRequired !== false,
    user: u ? { username: u.username, globalName: u.globalName, avatar: u.avatar, inGuild: u.inGuild, needGuild: !!settings.discordGuildId,
                connections: (u.connections || []).filter(c => PLATFORMS.includes(c.type)) } : null,
  });
});

// ============================================================
//  HYR ME DISCORD (OAuth2) - per aplikimet
//  Scopes: identify (llogaria), connections (Twitch/YouTube/TikTok...), guilds (anetaresia)
// ============================================================
const userSessions = new Map(); // token -> { user, exp }
const COOKIE_SECURE = () => siteUrl().startsWith('https://') ? '; Secure' : '';
function discordUser(req) {
  const t = getCookie(req, 'ugrp_user'); const s = t && userSessions.get(t);
  if (s && s.exp > Date.now()) return s.user;
  if (t) userSessions.delete(t);
  return null;
}
const discordRedirect = () => siteUrl() + '/auth/discord/callback';

app.get('/auth/discord', (req, res) => {
  if (!discordLoginOn()) return res.status(404).send('Hyrja me Discord nuk është aktivizuar.');
  const state = crypto.randomBytes(16).toString('hex');
  const ret = new URL(req.originalUrl || req.url, 'http://x').searchParams.get('ret') === 'spin' ? 'spin' : 'apply';
  res.set('Set-Cookie', [`ugrp_oauth=${state}; HttpOnly; SameSite=Lax; Path=/; Max-Age=600${COOKIE_SECURE()}`,
    `ugrp_ret=${ret}; HttpOnly; SameSite=Lax; Path=/; Max-Age=600${COOKIE_SECURE()}`]);
  const q = new URLSearchParams({ client_id: settings.discordClientId, redirect_uri: discordRedirect(), response_type: 'code',
    scope: 'identify connections guilds', state, prompt: 'none' });
  res.redirect('https://discord.com/oauth2/authorize?' + q);
});

const oauthLimits = new Map(); // ip -> [kohet]
app.get('/auth/discord/callback', async (req, res) => {
  const back = (msg) => res.redirect(getCookie(req, 'ugrp_ret') === 'spin' ? '/spin?discord=' + encodeURIComponent(msg)
    : '/streamers?discord=' + encodeURIComponent(msg) + '#apliko');
  const now = Date.now();
  const tries = (oauthLimits.get(req.ip) || []).filter(t => now - t < 10 * 60 * 1000);
  if (tries.length >= 15) return back('gabim');
  tries.push(now); oauthLimits.set(req.ip, tries);
  try {
    const u = new URL(req.originalUrl || req.url, 'http://x');
    const code = u.searchParams.get('code'), state = u.searchParams.get('state');
    if (!code || !state || state !== getCookie(req, 'ugrp_oauth')) return back('gabim');
    const tok = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: settings.discordClientId, client_secret: settings.discordClientSecret,
        grant_type: 'authorization_code', code, redirect_uri: discordRedirect() }),
    });
    if (!tok.ok) throw new Error('token ' + tok.status);
    const { access_token } = await tok.json();
    const H = { headers: { Authorization: 'Bearer ' + access_token } };
    const [me, connections, guilds] = await Promise.all([
      fetch('https://discord.com/api/users/@me', H).then(r => r.json()),
      fetch('https://discord.com/api/users/@me/connections', H).then(r => (r.ok ? r.json() : [])),
      fetch('https://discord.com/api/users/@me/guilds', H).then(r => (r.ok ? r.json() : [])),
    ]);
    if (!me?.id) throw new Error('pa perdorues');
    const createdAt = new Date(Number((BigInt(me.id) >> 22n) + 1420070400000n)).toISOString(); // data e krijimit te llogarise
    const user = {
      id: me.id, username: me.username, globalName: me.global_name || '',
      avatar: me.avatar ? `https://cdn.discordapp.com/avatars/${me.id}/${me.avatar}.png?size=128` : '',
      createdAt,
      inGuild: settings.discordGuildId ? (Array.isArray(guilds) && guilds.some(g => g.id === settings.discordGuildId)) : true,
      connections: (Array.isArray(connections) ? connections : []).map(c => ({ type: c.type, name: String(c.name || '').slice(0, 60), verified: !!c.verified })).slice(0, 30),
    };
    const t = crypto.randomBytes(32).toString('hex');
    userSessions.set(t, { user, exp: Date.now() + 2 * 3600 * 1000 });
    res.set('Set-Cookie', [`ugrp_user=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=7200${COOKIE_SECURE()}`, 'ugrp_oauth=; Path=/; Max-Age=0', 'ugrp_ret=; Path=/; Max-Age=0']);
    back('ok');
  } catch (e) {
    console.warn('[discord login]', e.message);
    back('gabim');
  }
});

app.post('/auth/discord/logout', (req, res) => {
  userSessions.delete(getCookie(req, 'ugrp_user'));
  res.set('Set-Cookie', 'ugrp_user=; Path=/; Max-Age=0');
  res.json({ ok: true });
});
app.get('/api/admin/applications', requireAdmin, (req, res) => res.json({ open: settings.applicationsOpen !== false, list: applications }));
app.post('/api/admin/applications/decide', requireAdmin, (req, res) => {
  const { id, action } = req.body || {};
  const a = applications.find(x => x.id === id);
  if (!a) return res.status(404).json({ error: 'Aplikimi nuk u gjet.' });
  if (action === 'delete') applications = applications.filter(x => x.id !== id);
  else if (action === 'accept') {
    a.status = 'accepted'; a.decidedAt = new Date().toISOString();
    const list = settings.streamers[a.platform] || [];
    if (!list.includes(a.username)) settings.streamers[a.platform] = [...list, a.username];
    writeJSON('settings.json', settings);
    cache.updated = 0; twitchProfiles.updated = 0;
  } else if (action === 'reject') { a.status = 'rejected'; a.decidedAt = new Date().toISOString(); }
  else return res.status(400).json({ error: 'Veprim i panjohur.' });
  audit(req, { accept: 'Aplikim u pranua', reject: 'Aplikim u refuzua', delete: 'Aplikim u fshi' }[action], `${a.platform}: ${a.username}`);
  writeJSON('applications.json', applications);
  res.json({ list: applications });
});

// ============================================================
//  VIZITORET (pa cookies, pa ruajtur IP)
//  Cdo vizitor njihet vetem per nje dite me hash(IP + browser + kripe e rastit qe ndryshon cdo dite).
// ============================================================
const PAGES = { '/': 'Kryefaqja', '/index.html': 'Kryefaqja', '/streamers': 'Streamerat', '/streamers.html': 'Streamerat',
  '/rregullat': 'Rregullat', '/rregullat.html': 'Rregullat', '/dyqani': 'Dyqani', '/dyqani.html': 'Dyqani',
  '/spin': 'Spin', '/spin.html': 'Spin', '/staff': 'Staff', '/staff.html': 'Staff' };
const BOT_RE = /bot|crawl|spider|slurp|preview|facebookexternalhit|embed|curl|wget|python|headless|monitor|uptime|scan/i;
let visits = readJSON('visits.json', { days: {}, salt: '', saltDay: '', seen: [] });
const dayKey = (d = new Date()) => d.toLocaleDateString('sv-SE', { timeZone: 'Europe/Tirane' }); // YYYY-MM-DD
let seenToday = new Set(visits.saltDay === dayKey() ? visits.seen || [] : []);
const online = new Map(); // id -> koha e fundit
let visitsDirty = false;

function trackVisit(req) {
  const page = PAGES[req.path];
  if (!page || req.method !== 'GET') return;
  const ua = String(req.headers['user-agent'] || '');
  if (!ua || BOT_RE.test(ua) || req.headers.purpose === 'prefetch' || getCookie(req, 'ugrp_admin')) return;
  const today = dayKey();
  if (visits.saltDay !== today) { // dite e re -> kripe e re, harrohen te gjithe
    visits.salt = crypto.randomBytes(16).toString('hex'); visits.saltDay = today; seenToday = new Set();
  }
  const id = crypto.createHash('sha256').update(visits.salt + '|' + req.ip + '|' + ua).digest('hex').slice(0, 16);
  const d = visits.days[today] ||= { views: 0, uniques: 0, pages: {}, refs: {} };
  d.views++;
  d.pages[page] = (d.pages[page] || 0) + 1;
  if (!seenToday.has(id)) {
    seenToday.add(id); d.uniques++;
    // nga erdhi (vetem domeni, p.sh. discord.com)
    let ref = 'Direkt';
    try {
      const h = new URL(req.headers.referer || '').hostname.replace(/^www\./, '');
      if (h && !h.endsWith('undergroundrp.tech')) ref = /discord/.test(h) ? 'Discord' : /tiktok/.test(h) ? 'TikTok' : /google\./.test(h) ? 'Google'
        : /youtube|youtu\.be/.test(h) ? 'YouTube' : /kick\.com/.test(h) ? 'Kick' : /twitch/.test(h) ? 'Twitch'
        : /instagram/.test(h) ? 'Instagram' : /facebook|fb\./.test(h) ? 'Facebook' : h.slice(0, 40);
    } catch {}
    if (Object.keys(d.refs).length < 50 || d.refs[ref]) d.refs[ref] = (d.refs[ref] || 0) + 1;
  }
  online.set(id, Date.now());
  visitsDirty = true;
}
app.use((req, res, next) => { try { trackVisit(req); } catch (e) { console.warn('[visits]', e.message); } next(); });

setInterval(() => {
  const now = Date.now();
  for (const [k, t] of online) if (now - t > 5 * 60 * 1000) online.delete(k);
  if (!visitsDirty) return;
  // mbaj vetem 400 ditet e fundit
  const keys = Object.keys(visits.days).sort();
  for (const k of keys.slice(0, Math.max(0, keys.length - 400))) delete visits.days[k];
  visits.seen = [...seenToday];
  writeJSON('visits.json', visits); visitsDirty = false;
}, 60 * 1000).unref();

app.get('/api/admin/visits', requireAdmin, (req, res) => {
  const now = Date.now();
  const sumDays = n => {
    let views = 0, uniques = 0;
    for (let i = 0; i < n; i++) { const d = visits.days[dayKey(new Date(now - i * 864e5))]; if (d) { views += d.views; uniques += d.uniques; } }
    return { views, uniques };
  };
  const merge = (n, field) => {
    const out = {};
    for (let i = 0; i < n; i++) { const d = visits.days[dayKey(new Date(now - i * 864e5))]; if (d) for (const [k, v] of Object.entries(d[field] || {})) out[k] = (out[k] || 0) + v; }
    return Object.entries(out).sort((a, b) => b[1] - a[1]).slice(0, 12);
  };
  const series = [];
  for (let i = 29; i >= 0; i--) { const k = dayKey(new Date(now - i * 864e5)); const d = visits.days[k]; series.push({ day: k, views: d?.views || 0, uniques: d?.uniques || 0 }); }
  const total = Object.values(visits.days).reduce((a, d) => ({ views: a.views + d.views, uniques: a.uniques + d.uniques }), { views: 0, uniques: 0 });
  const since = Object.keys(visits.days).sort()[0] || dayKey();
  res.json({
    online: [...online.values()].filter(t => now - t < 5 * 60 * 1000).length,
    today: sumDays(1), yesterday: (() => { const d = visits.days[dayKey(new Date(now - 864e5))]; return { views: d?.views || 0, uniques: d?.uniques || 0 }; })(),
    week: sumDays(7), month: sumDays(30), total, since, series,
    pages: merge(30, 'pages'), refs: merge(30, 'refs'),
  });
});

app.get('/api/admin/audit', requireAdmin, (req, res) => {
  let lines = [];
  try { lines = fs.readFileSync(AUDIT_FILE, 'utf8').trim().split('\n').filter(Boolean).slice(-150).reverse(); } catch {}
  res.json(lines.map(l => { const [time, ip, action, detail] = l.split(' | '); return { time, ip, action, detail: detail || '' }; }));
});

// ============================================================
//  SPIN - rrota ditore per lojtaret (hyrje me Discord, nje rrotullim ne cooldown)
//  Fitoret dalin te admini + Discord; admini ia jep lojtarit ne loje.
// ============================================================
const SPIN_DEFAULT = {
  enabled: false, cooldownHours: 24, minAccountDays: 30, requireGuild: true,
  prizes: [
    { label: '$5,000 cash', weight: 25, empty: false },
    { label: 'Provo nesër', weight: 20, empty: true },
    { label: '$10,000 cash', weight: 12, empty: false },
    { label: 'Kit ushqimi', weight: 10, empty: false },
    { label: '$25,000 cash', weight: 5, empty: false },
    { label: 'Provo nesër', weight: 20, empty: true },
    { label: 'VIP Bronze 3 ditë', weight: 5, empty: false },
    { label: 'Makinë 7 ditë', weight: 3, empty: false },
  ],
};
const spinCfg = () => ({ ...SPIN_DEFAULT, ...(settings.spin || {}) });
let spins = readJSON('spins.json', { last: {}, wins: [] });
spins.last ||= {}; spins.wins ||= [];

function spinState(u) {
  const c = spinCfg();
  const out = { enabled: !!c.enabled && discordLoginOn() && c.prizes.length >= 2, discordLogin: discordLoginOn(),
    cooldownHours: c.cooldownHours, prizes: c.prizes.map(p => ({ label: p.label, empty: !!p.empty, color: p.color || '' })), user: null };
  if (!u) return out;
  out.user = { name: u.globalName || u.username, avatar: u.avatar };
  const last = spins.last[u.id] ? Date.parse(spins.last[u.id]) : 0;
  const next = last + c.cooldownHours * 3600 * 1000;
  if (next > Date.now()) { out.nextAt = new Date(next).toISOString(); out.reason = 'cooldown'; }
  else if (c.requireGuild && settings.discordGuildId && !u.inGuild) out.reason = 'guild';
  else if (Date.now() - Date.parse(u.createdAt) < c.minAccountDays * 864e5) out.reason = 'young';
  out.canSpin = out.enabled && !out.reason;
  out.lastWin = spins.wins.find(w => w.discordId === u.id && Date.now() - Date.parse(w.at) < 7 * 864e5) || null;
  if (out.lastWin) out.lastWin = { prize: out.lastWin.prize, at: out.lastWin.at, status: out.lastWin.status };
  return out;
}

const isAdmin = req => { const t = getCookie(req, 'ugrp_admin'); const e = t && sessions.get(t); return !!(e && e > Date.now()); };
const recentWins = () => spins.wins.slice(0, 12).map(w => ({ name: String(w.name || '').slice(0, 24), prize: w.prize, at: w.at }));
app.get('/api/spin', (req, res) => {
  const out = spinState(discordUser(req));
  out.recent = out.enabled ? recentWins() : [];
  if (!out.enabled && isAdmin(req)) { // vetem admini e sheh pse eshte i mbyllur
    const c = spinCfg();
    out.adminHint = !discordLoginOn() ? 'Ndiz "Hyr me Discord" te Admin → Cilësimet (Client ID + Client Secret).'
      : !c.enabled ? 'Spin-i është i fikur. Shko te Admin → Spin, ndiz "Spin-i është i hapur për lojtarët" dhe kliko Ruaj spin-in.'
      : 'Duhen të paktën 2 shpërblime te Admin → Spin.';
  }
  res.json(out);
});

app.post('/api/spin', (req, res) => {
  const u = discordUser(req);
  if (!u) return res.status(401).json({ error: 'Hyr me Discord për të rrotulluar.' });
  const st = spinState(u);
  if (!st.enabled) return res.status(400).json({ error: 'Spin-i nuk është aktiv tani.' });
  if (st.reason === 'cooldown') return res.status(429).json({ error: 'E ke përdorur spin-in. Provo përsëri më vonë.', nextAt: st.nextAt });
  if (st.reason === 'guild') return res.status(403).json({ error: 'Duhet të jesh anëtar në Discord-in e serverit.' });
  if (st.reason === 'young') return res.status(403).json({ error: 'Llogaria jote e Discord është shumë e re.' });
  const prizes = spinCfg().prizes;
  const w = prizes.map(p => Math.round(Math.max(0, Number(p.weight) || 0) * 100)); // shansi ne % me 2 decimale
  const total = w.reduce((a, x) => a + x, 0);
  if (total <= 0) return res.status(400).json({ error: 'Spin-i nuk është aktiv tani.' });
  let r = crypto.randomInt(total), index = 0;
  for (; index < prizes.length; index++) { r -= w[index]; if (r < 0) break; }
  if (index >= prizes.length) index = prizes.length - 1;
  const prize = prizes[index];
  const at = new Date().toISOString();
  spins.last[u.id] = at;
  if (!prize.empty) {
    const win = { id: crypto.randomBytes(6).toString('hex'), discordId: u.id, username: u.username, name: u.globalName || u.username,
      prize: prize.label, at, status: 'pending' };
    spins.wins.unshift(win);
    spins.wins = spins.wins.slice(0, 1000);
    // nese s'ka kanal per spin, dergoje te kanali i aplikimeve (staff)
    sendWebhook(settings.webhooks?.spin ? 'spin' : 'applications', { embeds: [{
      title: 'Fitues në Spin', color: 0x8fd61f,
      description: `<@${u.id}> fitoi **${dcSafe(prize.label, 100)}**`,
      fields: [
        { name: 'Lojtari', value: `${dcSafe(win.name, 40)} (@${dcSafe(u.username, 40)})`, inline: true },
        { name: 'Discord ID', value: u.id, inline: true },
        { name: 'Shpërblimi', value: dcSafe(prize.label, 100), inline: true },
      ],
      footer: { text: 'Jepja në lojë dhe shëno "U dha" te paneli i adminit' }, timestamp: at,
    }] });
  }
  // pastro rrotullimet shume te vjetra
  for (const [k, t] of Object.entries(spins.last)) if (Date.now() - Date.parse(t) > 30 * 864e5) delete spins.last[k];
  writeJSON('spins.json', spins);
  res.json({ index, prize: { label: prize.label, empty: !!prize.empty }, nextAt: new Date(Date.parse(at) + spinCfg().cooldownHours * 3600 * 1000).toISOString() });
});

app.get('/api/admin/spin', requireAdmin, (req, res) => res.json({ config: spinCfg(), wins: spins.wins.slice(0, 300) }));
app.put('/api/admin/spin', requireAdmin, (req, res) => {
  const b = req.body || {};
  const prizes = (Array.isArray(b.prizes) ? b.prizes : []).slice(0, 12).map(p => ({
    label: String(p?.label || '').trim().slice(0, 40), weight: Math.min(100, Math.max(0, Math.round((Number(p?.weight) || 0) * 100) / 100)), empty: !!p?.empty,
    color: /^#[0-9a-f]{6}$/i.test(String(p?.color || '')) ? String(p.color).toLowerCase() : '',
  })).filter(p => p.label);
  if (prizes.length < 2) return res.status(400).json({ error: 'Duhen të paktën 2 shpërblime.' });
  if (!prizes.some(p => p.weight > 0)) return res.status(400).json({ error: 'Të paktën një shpërblim duhet të ketë shans mbi 0%.' });
  const sum = Math.round(prizes.reduce((a, p) => a + p.weight, 0) * 100) / 100;
  if (Math.abs(sum - 100) > 0.01) return res.status(400).json({ error: `Shanset duhet të bëjnë gjithsej 100%. Tani janë ${sum}%.` });
  settings.spin = {
    enabled: !!b.enabled, requireGuild: b.requireGuild !== false,
    cooldownHours: Math.min(720, Math.max(1, Math.round(Number(b.cooldownHours) || 24))),
    minAccountDays: Math.min(365, Math.max(0, Math.round(Number(b.minAccountDays) || 0))),
    prizes,
  };
  writeJSON('settings.json', settings);
  audit(req, 'spin ruajtur', `${settings.spin.enabled ? 'aktiv' : 'joaktiv'}, ${prizes.length} shpërblime`);
  res.json({ config: spinCfg(), wins: spins.wins.slice(0, 300) });
});
app.post('/api/admin/spin/win', requireAdmin, (req, res) => {
  const { id, action } = req.body || {};
  const w = spins.wins.find(x => x.id === id);
  if (!w) return res.status(404).json({ error: 'Nuk u gjet.' });
  if (action === 'given') { w.status = 'given'; w.givenAt = new Date().toISOString(); }
  else if (action === 'pending') { w.status = 'pending'; delete w.givenAt; }
  else if (action === 'delete') spins.wins = spins.wins.filter(x => x !== w);
  else return res.status(400).json({ error: 'Veprim i panjohur.' });
  writeJSON('spins.json', spins);
  audit(req, 'spin fitore', `${action} ${w.prize}`);
  res.json({ config: spinCfg(), wins: spins.wins.slice(0, 300) });
});

// /admin nuk duhet te dale ne Google
app.get('/admin', (req, res) => { res.set('X-Robots-Tag', 'noindex'); res.sendFile(path.join(__dirname, 'public', 'admin.html')); });

// Faqet: /, /rregullat, /streamers, /dyqani
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', 'index.html')));

// Gabimet nuk tregojne kurre detaje te brendshme (rruge, stack trace)
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.warn('[error]', err.message);
  res.status(status).json({ error: status === 413 ? 'Kërkesa është shumë e madhe.' : status < 500 ? 'Kërkesë e gabuar.' : 'Gabim në server.' });
});

// Pastro çdo 10 minuta sesionet dhe limitet e skaduara (qe memoria mos rritet pa fund)
setInterval(() => {
  const now = Date.now();
  for (const [k, exp] of sessions) if (exp < now) sessions.delete(k);
  for (const [k, s] of userSessions) if (s.exp < now) userSessions.delete(k);
  for (const [k, a] of loginAttempts) if (a.until < now && now - (a.t || 0) > 15 * 60 * 1000) loginAttempts.delete(k);
  for (const m of [applyLimits, oauthLimits]) for (const [k, t] of m) if (!t.some(x => now - x < 3600 * 1000)) m.delete(k);
  for (const [k, h] of apiHits) if (h.reset < now) apiHits.delete(k);
}, 10 * 60 * 1000).unref();

// Degjon vetem brenda VPS-it; nga jashte hyhet vetem permes Nginx (https://)
const HOST = process.env.HOST || '127.0.0.1';
app.listen(CONFIG.PORT, HOST, () => {
  console.log(`Streamers panel ne http://localhost:${CONFIG.PORT}`);
  console.log('Platformat aktive:', Object.entries(enabled()).filter(([, v]) => v).map(([k]) => k).join(', ') || 'asnje');
});
