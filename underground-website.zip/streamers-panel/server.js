// ============================================================
//  FiveM Live Streamers Panel - Twitch + Kick + TikTok
//  Backend: Node.js 20+ / Express
// ============================================================
require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
app.set('trust proxy', 1); // per Nginx / Render
app.use(express.json({ limit: '200kb' }));

const list = v => (v || '').split(',').map(s => s.trim().toLowerCase().replace(/^@/, '')).filter(Boolean);

// ---------------- KONFIGURIMI ----------------
const CONFIG = {
  PORT: process.env.PORT || 3000,
  CACHE_SECONDS: Number(process.env.CACHE_SECONDS || 60),

  // Emri / tag-u i serverit ne titullin e stream-it (p.sh. "emriserverit,#emriserverit")
  // Nese lihet bosh, shfaqen te gjithe streamerat e listes qe jane live (ne GTA V per Twitch/Kick)
  TITLE_KEYWORDS: list(process.env.TITLE_KEYWORDS),

  TWITCH: {
    get CLIENT_ID() { return settings.twitchClientId || process.env.TWITCH_CLIENT_ID; },
    get CLIENT_SECRET() { return settings.twitchClientSecret || process.env.TWITCH_CLIENT_SECRET; },
    STREAMERS: list(process.env.TWITCH_STREAMERS),
    SCAN_ALL_GTA: process.env.TWITCH_SCAN_ALL_GTA === 'true', // gjen edhe streamera jashte listes
  },
  KICK: {
    get CLIENT_ID() { return settings.kickClientId || process.env.KICK_CLIENT_ID; },
    get CLIENT_SECRET() { return settings.kickClientSecret || process.env.KICK_CLIENT_SECRET; },
    STREAMERS: list(process.env.KICK_STREAMERS), // slug-u i kanalit (kick.com/<slug>)
  },
  TIKTOK: {
    STREAMERS: list(process.env.TIKTOK_STREAMERS), // username pa @
    SIGN_API_KEY: process.env.TIKTOK_SIGN_API_KEY || undefined, // opsionale (eulerstream.com)
  },
};

// ============================================================
//  TE DHENAT QE NDRYSHON ADMINI (ruhen ne folderin data/)
// ============================================================
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

function readJSON(name, fallback) {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, name), 'utf8')); }
  catch { return fallback; }
}
function writeJSON(name, obj) {
  const file = path.join(DATA_DIR, name);
  fs.writeFileSync(file + '.tmp', JSON.stringify(obj, null, 2), { mode: 0o600 });
  fs.renameSync(file + '.tmp', file);
}

const DEFAULT_SETTINGS = {
  discord: process.env.DISCORD_INVITE || '',
  cfxCode: process.env.FIVEM_CODE || '',
  titleKeywords: CONFIG.TITLE_KEYWORDS,
  streamers: { twitch: CONFIG.TWITCH.STREAMERS, kick: CONFIG.KICK.STREAMERS, tiktok: CONFIG.TIKTOK.STREAMERS },
  tebexToken: process.env.TEBEX_TOKEN || '',
  tebexStoreUrl: process.env.TEBEX_STORE_URL || '',
  twitchClientId: '', twitchClientSecret: '', kickClientId: '', kickClientSecret: '',
};
let settings = { ...DEFAULT_SETTINGS, ...readJSON('settings.json', {}) };
settings.streamers = { twitch: [], kick: [], tiktok: [], ...settings.streamers };
if (!fs.existsSync(path.join(DATA_DIR, 'settings.json'))) writeJSON('settings.json', settings);

const streamersOf = p => settings.streamers[p] || [];
const enabled = () => ({
  twitch: !!(CONFIG.TWITCH.CLIENT_ID && CONFIG.TWITCH.CLIENT_SECRET && (streamersOf('twitch').length || CONFIG.TWITCH.SCAN_ALL_GTA)),
  kick: !!(CONFIG.KICK.CLIENT_ID && CONFIG.KICK.CLIENT_SECRET && streamersOf('kick').length),
  tiktok: streamersOf('tiktok').length > 0,
});

// ---------------- NDIHMESE ----------------
function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function matchesKeywords(title) {
  const keys = settings.titleKeywords || [];
  if (!keys.length) return true;
  const t = (title || '').toLowerCase();
  return keys.some(k => t.includes(k));
}

const isGta = name => /grand theft auto|gta/i.test(name || '');

// Token-a OAuth (client credentials) me cache
function tokenManager(fetchToken) {
  let token = null, expires = 0;
  return {
    async get() {
      if (token && Date.now() < expires) return token;
      const data = await fetchToken();
      token = data.access_token;
      expires = Date.now() + ((data.expires_in || 3600) - 300) * 1000;
      return token;
    },
    reset() { token = null; },
  };
}

// ============================================================
//  TWITCH
// ============================================================
const TWITCH_GTA_ID = '32982';

const twitchToken = tokenManager(async () => {
  const body = new URLSearchParams({
    client_id: CONFIG.TWITCH.CLIENT_ID,
    client_secret: CONFIG.TWITCH.CLIENT_SECRET,
    grant_type: 'client_credentials',
  });
  const res = await fetch('https://id.twitch.tv/oauth2/token', { method: 'POST', body });
  if (!res.ok) throw new Error('Twitch token error ' + res.status);
  return res.json();
});

async function twitch(endpoint, retry = true) {
  const res = await fetch(`https://api.twitch.tv/helix/${endpoint}`, {
    headers: { 'Client-ID': CONFIG.TWITCH.CLIENT_ID, Authorization: `Bearer ${await twitchToken.get()}` },
  });
  if (res.status === 401 && retry) { twitchToken.reset(); return twitch(endpoint, false); }
  if (!res.ok) throw new Error('Twitch API error ' + res.status);
  return res.json();
}

// Profilet e streamerave te listes (per seksionin Offline) - rifreskohen cdo 30 min
let twitchProfiles = { updated: 0, users: [] };
async function getTwitchProfiles() {
  if (Date.now() - twitchProfiles.updated < 30 * 60 * 1000) return twitchProfiles.users;
  const users = [];
  for (const group of chunk(streamersOf('twitch'), 100)) {
    const { data } = await twitch('users?' + group.map(l => `login=${encodeURIComponent(l)}`).join('&'));
    users.push(...data);
  }
  twitchProfiles = { updated: Date.now(), users };
  return users;
}

async function fetchTwitch() {
  const raw = [];

  for (const group of chunk(streamersOf('twitch'), 100)) {
    const q = group.map(l => `user_login=${encodeURIComponent(l)}`).join('&');
    const { data } = await twitch(`streams?${q}&first=100`);
    raw.push(...data.filter(s => s.game_id === TWITCH_GTA_ID && matchesKeywords(s.title)));
  }

  if (CONFIG.TWITCH.SCAN_ALL_GTA && (settings.titleKeywords || []).length) {
    let cursor = '';
    for (let page = 0; page < 10; page++) {
      const { data, pagination } = await twitch(
        `streams?game_id=${TWITCH_GTA_ID}&first=100${cursor ? `&after=${cursor}` : ''}`
      );
      raw.push(...data.filter(s => matchesKeywords(s.title)));
      if (!pagination?.cursor) break;
      cursor = pagination.cursor;
    }
  }

  const unique = [...new Map(raw.map(s => [s.user_id, s])).values()];

  const avatars = {};
  for (const group of chunk(unique.map(s => s.user_id), 100)) {
    const { data } = await twitch('users?' + group.map(id => `id=${id}`).join('&'));
    data.forEach(u => (avatars[u.id] = u.profile_image_url));
  }

  const profiles = await getTwitchProfiles().catch(() => []);
  const roster = profiles.map(u => ({
    platform: 'twitch', name: u.display_name, login: u.login,
    avatar: u.profile_image_url, url: `https://twitch.tv/${u.login}`,
  }));

  const live = unique.map(s => ({
    platform: 'twitch',
    login: s.user_login,
    name: s.user_name,
    title: s.title,
    viewers: s.viewer_count,
    startedAt: s.started_at,
    thumbnail: s.thumbnail_url.replace('{width}', '640').replace('{height}', '360'),
    avatar: avatars[s.user_id] || '',
    url: `https://twitch.tv/${s.user_login}`,
  }));
  return { live, roster };
}

// ============================================================
//  KICK (API zyrtar: api.kick.com/public)
// ============================================================
const kickToken = tokenManager(async () => {
  const body = new URLSearchParams({
    client_id: CONFIG.KICK.CLIENT_ID,
    client_secret: CONFIG.KICK.CLIENT_SECRET,
    grant_type: 'client_credentials',
  });
  const res = await fetch('https://id.kick.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!res.ok) throw new Error('Kick token error ' + res.status);
  return res.json();
});

async function kick(endpoint, retry = true) {
  const res = await fetch(`https://api.kick.com/public/${endpoint}`, {
    headers: { Authorization: `Bearer ${await kickToken.get()}`, Accept: 'application/json' },
  });
  if (res.status === 401 && retry) { kickToken.reset(); return kick(endpoint, false); }
  if (!res.ok) throw new Error('Kick API error ' + res.status);
  return res.json();
}

const kickAvatarMemory = {};

async function fetchKick() {
  // 1) Merr kanalet sipas slug-ut -> kush eshte live
  const live = [];
  const channels = [];
  for (const group of chunk(streamersOf('kick'), 50)) {
    const { data } = await kick('v1/channels?' + group.map(s => `slug=${encodeURIComponent(s)}`).join('&'));
    (data || []).forEach(c => {
      channels.push(c);
      if (c.stream?.is_live && isGta(c.category?.name) && matchesKeywords(c.stream_title)) live.push(c);
    });
  }

  // 2) Merr foton e profilit per ata qe jane live
  const avatars = {};
  if (live.length) try {
    for (const group of chunk(live.map(c => c.broadcaster_user_id), 100)) {
      const { data } = await kick('v1/users/livestreams?' + group.map(id => `user_id=${id}`).join('&'));
      (data || []).forEach(l => (avatars[l.broadcaster_user?.id] = l.broadcaster_user?.profile_picture));
    }
  } catch (e) { /* avatar-i eshte opsional */ }

  // Avatar-et e kanaleve offline ruhen nga hera e fundit qe kane qene live
  Object.entries(avatars).forEach(([id, url]) => url && (kickAvatarMemory[id] = url));
  const roster = channels.map(c => ({
    platform: 'kick', name: c.slug, login: c.slug,
    avatar: kickAvatarMemory[c.broadcaster_user_id] || '', url: `https://kick.com/${c.slug}`,
  }));

  return { roster, live: live.map(c => ({
    platform: 'kick',
    login: c.slug,
    name: c.slug,
    title: c.stream_title,
    viewers: c.stream.viewer_count || 0,
    startedAt: c.stream.start_time,
    thumbnail: c.stream.thumbnail || '',
    avatar: avatars[c.broadcaster_user_id] || '',
    url: `https://kick.com/${c.slug}`,
  })) };
}

// ============================================================
//  TIKTOK (pa API zyrtar - perdor librarine tiktok-live-connector)
// ============================================================
let TikTokLiveConnection;
async function loadTikTok() {
  if (!TikTokLiveConnection) ({ TikTokLiveConnection } = await import('tiktok-live-connector'));
  return TikTokLiveConnection;
}

const pick = (obj, ...paths) => {
  for (const p of paths) {
    const v = p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return undefined;
};

const tiktokAvatarMemory = {};

async function checkTikTokUser(username) {
  const Conn = await loadTikTok();
  const conn = new Conn(username, { signApiKey: CONFIG.TIKTOK.SIGN_API_KEY });
  if (!(await conn.fetchIsLive())) return null;

  const info = await conn.fetchRoomInfo().catch(() => ({}));
  const room = info?.data || info || {};
  const title = pick(room, 'title') || '';
  if (!matchesKeywords(title)) return null;

  const created = pick(room, 'create_time');
  const avatar = pick(room, 'owner.avatar_thumb.url_list.0', 'owner.avatar_medium.url_list.0') || '';
  if (avatar) tiktokAvatarMemory[username] = avatar;
  return {
    platform: 'tiktok',
    login: username,
    name: pick(room, 'owner.nickname', 'owner.display_id') || username,
    title,
    viewers: Number(pick(room, 'user_count', 'stats.user_count_composition', 'room_view_stats.display_value') || 0),
    startedAt: created ? new Date(created * 1000).toISOString() : null,
    thumbnail: pick(room, 'cover.url_list.0') || '',
    avatar,
    url: `https://www.tiktok.com/@${username}/live`,
  };
}

async function fetchTikTok() {
  const out = [];
  // Kontrollo 5 njeheresh qe mos te bllokohemi nga TikTok
  for (const group of chunk(streamersOf('tiktok'), 5)) {
    const results = await Promise.allSettled(group.map(checkTikTokUser));
    results.forEach((r, i) => {
      if (r.status === 'fulfilled' && r.value) out.push(r.value);
      else if (r.status === 'rejected') console.warn(`[TikTok] ${group[i]}:`, r.reason?.message || r.reason);
    });
  }
  const roster = streamersOf('tiktok').map(u => ({
    platform: 'tiktok', name: u, login: u,
    avatar: tiktokAvatarMemory[u] || '', url: `https://www.tiktok.com/@${u}`,
  }));
  return { live: out, roster };
}

// ============================================================
//  CACHE + API
// ============================================================
let cache = { updated: 0, streams: [], offline: [], errors: {} };
let refreshing = null;

async function refresh() {
  const on = enabled();
  const jobs = {
    twitch: on.twitch ? fetchTwitch() : Promise.resolve({ live: [], roster: [] }),
    kick: on.kick ? fetchKick() : Promise.resolve({ live: [], roster: [] }),
    tiktok: on.tiktok ? fetchTikTok() : Promise.resolve({ live: [], roster: [] }),
  };
  const keys = Object.keys(jobs);
  const results = await Promise.allSettled(Object.values(jobs));

  const streams = [];
  const roster = [];
  const errors = {};
  results.forEach((r, i) => {
    const platform = keys[i];
    if (r.status === 'fulfilled') { streams.push(...r.value.live); roster.push(...r.value.roster); }
    else {
      errors[platform] = r.reason?.message || 'error';
      console.error(`[${platform}]`, r.reason);
      // mbaj te dhenat e vjetra te asaj platforme nese deshtoi
      streams.push(...cache.streams.filter(s => s.platform === platform));
      roster.push(...cache.offline.filter(s => s.platform === platform));
    }
  });

  const liveKeys = new Set(streams.map(s => s.platform + ':' + s.login));
  const offline = roster
    .filter(s => !liveKeys.has(s.platform + ':' + s.login))
    .sort((a, b) => a.name.localeCompare(b.name));

  cache = { updated: Date.now(), streams: streams.sort((a, b) => b.viewers - a.viewers), offline, errors };
}

app.get('/api/live', async (req, res) => {
  if (Date.now() - cache.updated > CONFIG.CACHE_SECONDS * 1000) {
    refreshing ||= refresh().finally(() => (refreshing = null));
    await refreshing;
  }
  const by = p => cache.streams.filter(s => s.platform === p).length;
  res.json({
    count: cache.streams.length,
    totalViewers: cache.streams.reduce((a, s) => a + s.viewers, 0),
    platforms: { twitch: by('twitch'), kick: by('kick'), tiktok: by('tiktok') },
    updated: cache.updated,
    streams: cache.streams,
    offline: cache.offline,
  });
});

// ============================================================
//  STATUSI I SERVERIT FIVEM (lojtaret online)
// ============================================================
let statusCache = { updated: 0, data: { online: false } };

app.get('/api/status', async (req, res) => {
  const code = settings.cfxCode;
  if (!code) return res.status(404).json({ online: false, error: 'Kodi cfx mungon' });

  if (Date.now() - statusCache.updated > 60 * 1000) {
    try {
      const r = await fetch(`https://servers-frontend.fivem.net/api/servers/single/${encodeURIComponent(code)}`, {
        headers: { 'User-Agent': 'Mozilla/5.0 (UndergroundRP website)', Accept: 'application/json' },
      });
      if (!r.ok) throw new Error('FiveM ' + r.status);
      const { Data } = await r.json();
      statusCache.data = { online: true, players: Data.clients ?? 0, maxPlayers: Data.sv_maxclients ?? Data.svMaxclients ?? 0 };
    } catch (e) {
      console.warn('[status]', e.message);
      statusCache.data = { online: false };
    }
    statusCache.updated = Date.now();
  }
  res.json(statusCache.data);
});

// ============================================================
//  KONFIGURIMI PUBLIK I FAQES (/config.js)
// ============================================================
app.get('/config.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'no-cache');
  res.send('window.SITE = ' + JSON.stringify({
    name: 'Underground RP',
    discord: settings.discord || '#',
    cfxCode: settings.cfxCode || '',
  }) + ';');
});

// ============================================================
//  RREGULLAT
// ============================================================
let rules = readJSON('rules.json', []);
app.get('/api/rules', (req, res) => res.json(rules));

// ============================================================
//  DYQANI - TEBEX (paketat lexohen nga Tebex Headless API)
// ============================================================
let shopCache = { updated: 0, key: '', data: null };

app.get('/api/shop', async (req, res) => {
  const token = settings.tebexToken;
  if (!token) return res.json({ open: false, categories: [] });

  if (shopCache.key !== token || Date.now() - shopCache.updated > 5 * 60 * 1000) {
    try {
      const r = await fetch(`https://headless.tebex.io/api/accounts/${encodeURIComponent(token)}/categories?includePackages=1`,
        { headers: { Accept: 'application/json' } });
      if (!r.ok) throw new Error('Tebex ' + r.status);
      const { data } = await r.json();
      const store = (settings.tebexStoreUrl || '').replace(/\/+$/, '');
      shopCache.data = (data || []).map(c => ({
        name: c.name,
        packages: (c.packages || []).map(p => ({
          id: p.id,
          name: p.name,
          description: String(p.description || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 220),
          image: p.image || '',
          price: p.total_price ?? p.base_price ?? 0,
          currency: p.currency || 'EUR',
          url: store ? `${store}/package/${p.id}` : '',
        })),
      })).filter(c => c.packages.length);
      shopCache.updated = Date.now();
      shopCache.key = token;
    } catch (e) {
      console.warn('[tebex]', e.message);
      if (!shopCache.data) return res.json({ open: false, categories: [] });
    }
  }
  res.json({ open: shopCache.data.length > 0, storeUrl: settings.tebexStoreUrl || '', categories: shopCache.data });
});

// ============================================================
//  PANELI I ADMINIT
// ============================================================
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const sessions = new Map(); // token -> skadimi
const loginAttempts = new Map(); // ip -> { n, until }

const sha = s => crypto.createHash('sha256').update(String(s)).digest();
function getCookie(req, name) {
  const m = (req.headers.cookie || '').match(new RegExp('(?:^|; )' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : null;
}
function requireAdmin(req, res, next) {
  const t = getCookie(req, 'ugrp_admin');
  const exp = t && sessions.get(t);
  if (exp && exp > Date.now()) return next();
  if (t) sessions.delete(t);
  res.status(401).json({ error: 'Duhet të hysh si admin.' });
}

app.post('/api/admin/login', (req, res) => {
  const ip = req.ip;
  const a = loginAttempts.get(ip) || { n: 0, until: 0 };
  if (a.until > Date.now()) return res.status(429).json({ error: 'Shumë tentativa. Provo pas 15 minutash.' });
  if (!ADMIN_PASSWORD) return res.status(500).json({ error: 'ADMIN_PASSWORD nuk është vendosur te .env' });

  const ok = crypto.timingSafeEqual(sha(req.body?.password || ''), sha(ADMIN_PASSWORD));
  if (!ok) {
    a.n++; if (a.n >= 5) { a.n = 0; a.until = Date.now() + 15 * 60 * 1000; }
    loginAttempts.set(ip, a);
    return res.status(401).json({ error: 'Fjalëkalimi është gabim.' });
  }
  loginAttempts.delete(ip);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now() + 12 * 60 * 60 * 1000);
  res.set('Set-Cookie', `ugrp_admin=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${req.secure ? '; Secure' : ''}`);
  res.json({ ok: true });
});

app.post('/api/admin/logout', (req, res) => {
  sessions.delete(getCookie(req, 'ugrp_admin'));
  res.set('Set-Cookie', 'ugrp_admin=; Path=/; Max-Age=0');
  res.json({ ok: true });
});

// Sekretet nuk dergohen kurre te browser-i, vetem nese jane vendosur
const SECRET_KEYS = ['twitchClientSecret', 'kickClientSecret'];
function publicSettings() {
  const out = { ...settings };
  for (const k of SECRET_KEYS) { out[k] = ''; out[k + 'Set'] = !!(settings[k] || process.env[k === 'twitchClientSecret' ? 'TWITCH_CLIENT_SECRET' : 'KICK_CLIENT_SECRET']); }
  out.twitchClientId = settings.twitchClientId || process.env.TWITCH_CLIENT_ID || '';
  out.kickClientId = settings.kickClientId || process.env.KICK_CLIENT_ID || '';
  out.errors = cache.errors || {};
  return out;
}
app.get('/api/admin/settings', requireAdmin, (req, res) => res.json(publicSettings()));

const cleanName = v => String(v || '').trim().toLowerCase().replace(/^@/, '').replace(/^(https?:\/\/)?(www\.|m\.)?[a-z0-9-]+\.[a-z]{2,}\/@?/, '').replace(/\/.*$/, '');
const validName = v => /^[a-z0-9_.]{2,40}$/.test(v);

app.put('/api/admin/settings', requireAdmin, (req, res) => {
  const b = req.body || {};
  const next = { ...settings };

  if (b.discord !== undefined) {
    const d = String(b.discord).trim();
    if (d && !/^https:\/\/(discord\.gg|discord\.com\/invite)\/[\w-]+$/.test(d))
      return res.status(400).json({ error: 'Linku i Discord duhet të jetë si https://discord.gg/abc123' });
    next.discord = d;
  }
  if (b.cfxCode !== undefined) {
    const c = String(b.cfxCode).trim().replace(/^.*join\//, '');
    if (c && !/^[a-z0-9]{4,12}$/i.test(c)) return res.status(400).json({ error: 'Kodi cfx duhet të jetë si pgggd68' });
    next.cfxCode = c;
  }
  if (b.titleKeywords !== undefined) {
    next.titleKeywords = [].concat(b.titleKeywords).map(k => String(k).trim().toLowerCase()).filter(Boolean).slice(0, 10);
  }
  if (b.streamers !== undefined) {
    const out = {};
    for (const p of ['twitch', 'kick', 'tiktok']) {
      const names = [...new Set([].concat(b.streamers[p] || []).map(cleanName).filter(Boolean))];
      const bad = names.find(n => !validName(n));
      if (bad) return res.status(400).json({ error: `Username jo i saktë te ${p}: "${bad}"` });
      out[p] = names.slice(0, 300);
    }
    next.streamers = out;
  }
  if (b.tebexToken !== undefined) {
    const t = String(b.tebexToken).trim();
    if (t && !/^[\w-]{6,80}$/.test(t)) return res.status(400).json({ error: 'Tokeni i Tebex nuk duket i saktë.' });
    next.tebexToken = t;
  }
  if (b.tebexStoreUrl !== undefined) {
    const u = String(b.tebexStoreUrl).trim();
    if (u && !/^https:\/\/[\w.-]+(\/.*)?$/.test(u)) return res.status(400).json({ error: 'Linku i dyqanit duhet të nisë me https://' });
    next.tebexStoreUrl = u;
  }

  for (const k of ['twitchClientId', 'kickClientId', ...SECRET_KEYS]) {
    if (b[k] === undefined) continue;
    const v = String(b[k]).trim();
    if (!v) continue; // bosh = mbaj vleren e vjeter
    if (!/^[\w-]{8,100}$/.test(v)) return res.status(400).json({ error: 'Çelësi nuk duket i saktë: ' + k });
    next[k] = v;
  }

  settings = next;
  writeJSON('settings.json', settings);
  twitchToken.reset(); kickToken.reset();
  // rifresko menjehere listat
  cache.updated = 0; twitchProfiles.updated = 0; shopCache.updated = 0; statusCache.updated = 0;
  res.json(publicSettings());
});

app.put('/api/admin/rules', requireAdmin, (req, res) => {
  const b = req.body;
  if (!Array.isArray(b) || b.length > 40) return res.status(400).json({ error: 'Format i gabuar.' });
  const clean = [];
  for (const c of b) {
    const title = String(c?.title || '').trim().slice(0, 80);
    if (!title) return res.status(400).json({ error: 'Çdo kategori duhet të ketë titull.' });
    const items = (Array.isArray(c.rules) ? c.rules : []).slice(0, 60)
      .map(r => [String(r?.[0] || '').trim().slice(0, 100), String(r?.[1] || '').trim().slice(0, 1000)])
      .filter(r => r[0] || r[1]);
    clean.push({ title, icon: String(c.icon || '').slice(0, 4), rules: items });
  }
  rules = clean;
  writeJSON('rules.json', rules);
  res.json(rules);
});

// ============================================================
//  NJOFTIMET / LAJMET
// ============================================================
let news = readJSON('news.json', []);
const NEWS_TYPES = ['Njoftim', 'Përditësim', 'Event'];
app.get('/api/news', (req, res) => res.json(news.slice(0, 20)));

app.get('/api/admin/news', requireAdmin, (req, res) => res.json(news));

app.put('/api/admin/news', requireAdmin, (req, res) => {
  const b = req.body;
  if (!Array.isArray(b) || b.length > 100) return res.status(400).json({ error: 'Format i gabuar.' });
  const clean = [];
  for (const n of b) {
    const title = String(n?.title || '').trim().slice(0, 120);
    const text = String(n?.text || '').trim().slice(0, 3000);
    if (!title) return res.status(400).json({ error: 'Çdo njoftim duhet të ketë titull.' });
    const date = /^\d{4}-\d{2}-\d{2}$/.test(n?.date) ? n.date : new Date().toISOString().slice(0, 10);
    clean.push({
      id: String(n?.id || crypto.randomBytes(6).toString('hex')).slice(0, 20),
      title, text, date,
      type: NEWS_TYPES.includes(n?.type) ? n.type : 'Njoftim',
    });
  }
  clean.sort((x, y) => y.date.localeCompare(x.date));
  news = clean;
  writeJSON('news.json', news);
  res.json(news);
});

// /admin nuk duhet te dale ne Google
app.get('/admin', (req, res) => { res.set('X-Robots-Tag', 'noindex'); res.sendFile(path.join(__dirname, 'public', 'admin.html')); });

// Faqet: /, /rregullat, /streamers, /dyqani
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(CONFIG.PORT, () => {
  console.log(`Streamers panel ne http://localhost:${CONFIG.PORT}`);
  console.log('Platformat aktive:', Object.entries(enabled()).filter(([, v]) => v).map(([k]) => k).join(', ') || 'asnje');
});
