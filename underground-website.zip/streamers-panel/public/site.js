// Menuja, footer-i dhe linqet e perbashketa per te gjitha faqet
(function () {
  const S = window.SITE || {};
  const page = document.body.dataset.page || '';
  const links = [
    ['home', '/', 'Kryefaqja'],
    ['rregullat', '/rregullat', 'Rregullat'],
    ['streamers', '/streamers', 'Streamerat'],
    ['dyqani', '/dyqani', 'Dyqani'],
    ['staff', '/staff', 'Staff'],
  ];
  const navLinks = links.map(([id, href, label]) =>
    `<a href="${href}" class="${id === page ? 'active' : ''}">${label}</a>`).join('');

  const nav = document.getElementById('nav');
  if (nav) nav.outerHTML = `
    <nav>
      <div class="container">
        <a class="brand" href="/"><img src="logo-sm.png" alt=""><span>Underground <b>RP</b></span></a>
        <div class="nav-links">${navLinks}</div>
        <div class="nav-right">
          <a class="btn" data-discord target="_blank" rel="noopener">Discord</a>
          <button class="burger" aria-label="Menuja" onclick="document.body.classList.toggle('menu-open')">
            <span></span><span></span><span></span>
          </button>
        </div>
      </div>
      <div class="mobile-menu">${navLinks}<a data-connect class="btn">Lidhu në server</a></div>
    </nav>`;

  const socials = [['Discord', S.discord], ['TikTok', S.tiktok], ['YouTube', S.youtube], ['Instagram', S.instagram]]
    .filter(([, u]) => u).map(([n, u]) => `<a href="${u}" target="_blank" rel="noopener">${n}</a>`).join('');

  const footer = document.getElementById('footer');
  if (footer) footer.outerHTML = `
    <footer>
      <div class="container">
        <div>
          <div class="brand" style="font-size:18px"><img src="logo-sm.png" alt="" style="height:30px;width:30px"><span>Underground <b>RP</b></span></div>
          <p style="margin-top:8px">© ${new Date().getFullYear()} ${S.name}. Të gjitha të drejtat e rezervuara.</p>
          <p>Nuk jemi të lidhur me Rockstar Games ose Take-Two Interactive.</p>
        </div>
        <div class="foot-links">${navLinks}</div>
        <div class="foot-links">${socials}</div>
      </div>
    </footer>`;

  // Linqet e Discord-it dhe connect
  const connectUrl = `fivem://connect/cfx.re/join/${S.cfxCode}`;
  document.querySelectorAll('[data-discord]').forEach(a => (a.href = S.discord));
  document.querySelectorAll('[data-connect]').forEach(a => (a.href = connectUrl));
  document.querySelectorAll('[data-connect-text]').forEach(el => (el.textContent = `connect cfx.re/join/${S.cfxCode}`));
})();

// Kopjo tekstin (p.sh. komanden connect)
function copyText(id, btn) {
  const text = document.getElementById(id).textContent;
  navigator.clipboard.writeText(text).then(() => {
    const old = btn.textContent;
    btn.textContent = 'U kopjua ✓';
    setTimeout(() => (btn.textContent = old), 1500);
  });
}
