#!/usr/bin/env bash
# ============================================================
#  Underground RP - instalimi automatik i website-it ne VPS
#  Ubuntu 22.04 / 24.04. Nise si root:  bash install.sh
# ============================================================
set -e

DOMAIN="undergroundrp.tech"
APP_DIR="/opt/underground"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

green() { echo -e "\n\e[32m==> $1\e[0m"; }

# ---------- 1) Fjalekalimi i adminit ----------
if [ ! -f "$APP_DIR/.env" ] || grep -q "ndrysho-kete-fjalekalim" "$APP_DIR/.env"; then
  echo
  while true; do
    read -rsp "Zgjidh fjalekalimin e panelit /admin (min. 8 shkronja): " PW1; echo
    read -rsp "Shkruaje perseri: " PW2; echo
    if [ "$PW1" != "$PW2" ]; then echo "Nuk perputhen, provo perseri."; continue; fi
    if [ ${#PW1} -lt 8 ]; then echo "Shume i shkurter, provo perseri."; continue; fi
    break
  done
fi

# ---------- 2) Paketat e sistemit ----------
green "Duke instaluar programet (mund te zgjase 2-3 minuta)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates nginx certbot python3-certbot-nginx unzip

if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 20 ]; then
  green "Duke instaluar Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
npm install -g pm2 >/dev/null 2>&1

# ---------- 3) Kopjo website-in ----------
green "Duke kopjuar website-in ne $APP_DIR..."
mkdir -p "$APP_DIR"
# ruaj te dhenat ekzistuese (streamerat, rregullat, .env) kur perditeson
[ -d "$APP_DIR/data" ] && cp -r "$APP_DIR/data" /tmp/ugrp-data-backup
[ -f "$APP_DIR/.env" ] && cp "$APP_DIR/.env" /tmp/ugrp-env-backup
cp -r "$SRC_DIR/." "$APP_DIR/"
[ -d /tmp/ugrp-data-backup ] && cp -r /tmp/ugrp-data-backup/. "$APP_DIR/data/" && rm -rf /tmp/ugrp-data-backup
[ -f /tmp/ugrp-env-backup ] && cp /tmp/ugrp-env-backup "$APP_DIR/.env" && rm -f /tmp/ugrp-env-backup
[ -f "$APP_DIR/.env" ] || cp "$APP_DIR/.env.example" "$APP_DIR/.env"

if [ -n "$PW1" ]; then
  ESCAPED=$(printf '%s' "$PW1" | sed -e 's/[\/&|]/\\&/g')
  sed -i "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=$ESCAPED|" "$APP_DIR/.env"
fi
chmod 600 "$APP_DIR/.env"

cd "$APP_DIR"
green "Duke instaluar varesite e website-it..."
npm install --omit=dev

# ---------- 4) Nise dhe mbaje ndezur ----------
green "Duke nisur website-in..."
pm2 delete underground >/dev/null 2>&1 || true
pm2 start server.js --name underground
pm2 save
pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true

# ---------- 5) Nginx (domeni -> website) ----------
green "Duke lidhur domenin $DOMAIN..."
cat > /etc/nginx/sites-available/underground <<NGINX
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
NGINX
ln -sf /etc/nginx/sites-available/underground /etc/nginx/sites-enabled/underground
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow 'Nginx Full' >/dev/null
fi

# ---------- 6) HTTPS falas (Let's Encrypt) ----------
green "Duke aktivizuar HTTPS..."
if certbot --nginx -d "$DOMAIN" -d "www.$DOMAIN" --non-interactive --agree-tos \
     --register-unsafely-without-email --redirect; then
  URL="https://$DOMAIN"
else
  echo
  echo "HTTPS nuk u aktivizua ende (domeni mund te mos jete perhapur akoma)."
  echo "Provo perseri pas pak me:  certbot --nginx -d $DOMAIN -d www.$DOMAIN --redirect"
  URL="http://$DOMAIN"
fi

echo
echo "============================================================"
echo "  GATI!  Website:  $URL"
echo "         Admin:    $URL/admin"
echo "============================================================"
echo "Celesat e Twitch/Kick i vendos me:  nano $APP_DIR/.env"
echo "pastaj:  pm2 restart underground"
