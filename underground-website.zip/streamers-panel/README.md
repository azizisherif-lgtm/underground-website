# Underground RP - Website

Faqet: Kryefaqja (/), Rregullat (/rregullat), Streamerat (/streamers), Dyqani (/dyqani)
Paneli i adminit: /admin

## Paneli i adminit (/admin)
Hyn me fjalekalimin `ADMIN_PASSWORD` nga `.env`. Aty:
- **Streamerat:** shton/fshin streamera Twitch, Kick, TikTok (username ose linku i kanalit)
- **Rregullat:** ndryshon, shton, fshin rregulla dhe kategori
- **Cilesimet:** linku i Discord, kodi cfx, tag-u [ugrp], Tebex

Te dhenat ruhen ne folderin `data/` (mos e fshi).

## Dyqani VIP (Tebex)
1. Krijo dyqan falas te tebex.io dhe lidhe me serverin FiveM
2. Krijo paketat VIP te Tebex
3. Te Tebex: Integrations -> Headless API -> kopjo Public Token
4. Ne /admin -> Cilesimet: vendos tokenin dhe linkun e dyqanit -> Ruaj

Faqja "Dyqani" shfaq paketat vete. Pa token del "Coming Soon".

## .env (vetem nje here)
- `ADMIN_PASSWORD` - fjalekalimi i panelit (ndryshoje patjeter)
- `TWITCH_CLIENT_ID`, `TWITCH_CLIENT_SECRET` - nga dev.twitch.tv/console
- `KICK_CLIENT_ID`, `KICK_CLIENT_SECRET` - nga kick.com -> Settings -> Developer
- `FIVEM_CODE` - kodi i serverit (pgggd68)

## Nisja
1. Node.js 20+
2. `npm install`
3. `npm start` -> http://localhost:3000
